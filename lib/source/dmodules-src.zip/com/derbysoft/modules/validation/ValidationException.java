package com.derbysoft.modules.validation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.Assert;

public class ValidationException extends RuntimeException {

	private static final long serialVersionUID = -471666899091724145L;
	
	private List<String> failureMessages = new ArrayList<String>();

	public ValidationException(List<String> failureMessages) {
		super();
		Assert.notNull(failureMessages, "failureMessages required");
		this.failureMessages = failureMessages;
	}

	public List<String> getFailureMessages() {
		return failureMessages;
	}

	@Override
	public String getMessage() {
		StringBuilder builder = new StringBuilder();
		builder.append("Validate Failed, Detail Messages ");
		builder.append(getLineSeprator());
		
		for (int i = 0; i < failureMessages.size(); i++) {
			String failureMessage = failureMessages.get(i);
			builder.append(" [ ");
			builder.append(i + 1);
			builder.append(" ] ");
			builder.append(failureMessage);
			builder.append(getLineSeprator());
		}
		
		return builder.toString();
	}

	private String getLineSeprator() {
		return System.getProperty("line.separator");
	}
	
	


}
