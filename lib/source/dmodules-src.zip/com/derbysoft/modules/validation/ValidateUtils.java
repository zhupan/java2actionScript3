package com.derbysoft.modules.validation;

import java.util.Arrays;

public abstract class ValidateUtils {
	
	public static void validate(Validatable validatable) throws ValidationException {
		if (validatable == null) {
			throw new ValidationException(Arrays.asList(new String[] {"Object to validate missing"}));
		}
		validatable.validate();
	}
	
}
