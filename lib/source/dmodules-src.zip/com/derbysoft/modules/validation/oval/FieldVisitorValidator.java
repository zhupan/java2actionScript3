package com.derbysoft.modules.validation.oval;

import java.beans.PropertyDescriptor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import net.sf.oval.ConstraintViolation;
import net.sf.oval.Validator;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;

import com.derbysoft.modules.util.ClassUtils;


/**
 * <p>Field Visitor Validator for {@link Validator}, Not Thread-Safe.</p>
 * 
 * @author politics wang
 * @since 2008-05-04
 * @see Validator
 */
public class FieldVisitorValidator {

	private static Log logger = LogFactory.getLog(FieldVisitorValidator.class);
	
	private Validator validator;
	
	private boolean keepgoing = false;
	
	private List<ConstraintViolation> violations = new ArrayList<ConstraintViolation>();
	
	private List<Object> validatedReferences = new ArrayList<Object>();
	
	public FieldVisitorValidator() {
		validator = new Validator();
	}
	
	public FieldVisitorValidator(Validator validator) {
		Assert.notNull(validator, "validator required");
		this.validator = validator;
	}

	public void setKeepgoing(boolean keepgoing) {
		this.keepgoing = keepgoing;
	}

	public List<ConstraintViolation> validate(Object object) {
		if (validatedReferences.contains(object)) {
			return violations;
		}
		validatedReferences.add(object);
		
		violations.addAll(validator.validate(object));
		if (!keepgoing && !violations.isEmpty()) {
			return violations;
		}
		
		PropertyDescriptor[] descriptors = PropertyUtils.getPropertyDescriptors(object.getClass());
		
		for (PropertyDescriptor descriptor : descriptors) {
			Class<?> propertyType = descriptor.getPropertyType();
			if (ClassUtils.isBasicJavaTypeOrArray(propertyType)) {
				continue;
			}
			
			String propertyName = descriptor.getName();
			Object propertyValue = null;
			
			try {
				propertyValue = PropertyUtils.getProperty(object, propertyName);
			} catch (Exception e) {
				logger.debug("Evaluate [" + propertyName + "] failed, ignore it", e);
			}
			
			if (propertyValue == null) {
				continue;
			}
			
			if (Collection.class.isInstance(propertyValue)) {
				Collection<?> collection = (Collection<?>) propertyValue;
				validateArray(collection.toArray());
			} else if (propertyType.isArray()) {
				validateArray((Object[]) propertyValue);
			} else {
				validate(propertyValue);				
			}
		}
		
		return violations;
	}

	public void reset() {
		violations.clear();
		validatedReferences.clear();
	}
	
	private void validateArray(Object[] array) {
		for (Object foreach : array) {
			validate(foreach);
		}
	}

		
	
}
