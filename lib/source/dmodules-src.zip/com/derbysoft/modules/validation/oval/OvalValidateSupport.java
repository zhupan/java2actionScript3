package com.derbysoft.modules.validation.oval;

import java.util.ArrayList;
import java.util.List;

import net.sf.oval.ConstraintViolation;

import com.derbysoft.modules.eip.translator.Translator;
import com.derbysoft.modules.validation.Validatable;
import com.derbysoft.modules.validation.ValidationException;

public abstract class OvalValidateSupport implements Validatable {
	
	protected boolean keepgoingValidate = false;
	
	@Override
	public final void validate() throws ValidationException {
		FieldVisitorValidator validator = getValidator();
		List<ConstraintViolation> violations = validator.validate(this);
		violations.addAll(doValidate());
	
		if (!violations.isEmpty()) {
			Translator<List<ConstraintViolation>, ValidationException> translator 
				= new ConstraintViolation2ValidationExceptionTranslator();
			throw translator.translate(violations);
		}
	}
	
	protected FieldVisitorValidator getValidator() {
		FieldVisitorValidator validator = new FieldVisitorValidator();
		validator.setKeepgoing(keepgoingValidate);
		return validator;
	}
	
	/**
	 * Subclass can override this method do some custom validate operation
	 * @return violations, empty list if no validate error occurs
	 */
	protected List<ConstraintViolation> doValidate() {
		return new ArrayList<ConstraintViolation>();
	}

	public void setKeepgoingValidate(boolean keepgoingValidate) {
		this.keepgoingValidate = keepgoingValidate;
	}
	
	
	
}
