package com.derbysoft.modules.validation.oval;

import java.util.ArrayList;
import java.util.List;

import net.sf.oval.ConstraintViolation;

import com.derbysoft.modules.eip.translator.Translator;
import com.derbysoft.modules.validation.ValidationException;

public class ConstraintViolation2ValidationExceptionTranslator implements
		Translator<List<ConstraintViolation>, ValidationException> {

	@Override
	public ValidationException translate(List<ConstraintViolation> violations) {
		List<String> failureMessages = new ArrayList<String>(violations.size());
		
		for (ConstraintViolation violation : violations) {
			failureMessages.add(violation.getMessage());
		}
		
		return new ValidationException(failureMessages);
	}

}
