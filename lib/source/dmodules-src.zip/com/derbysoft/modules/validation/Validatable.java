package com.derbysoft.modules.validation;

public interface Validatable {
	
	void validate() throws ValidationException;
	
}
