package com.derbysoft.modules.util;

import static org.springframework.util.ClassUtils.isPrimitiveArray;
import static org.springframework.util.ClassUtils.isPrimitiveOrWrapper;
import static org.springframework.util.ClassUtils.isPrimitiveWrapperArray;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.springframework.util.Assert;

/**
 * @see org.springframework.util.ClassUtils
 */
public abstract class ClassUtils {
	
	@SuppressWarnings("unchecked")
	public static final List<Class> BASIC_JAVA_TYPES = Collections.unmodifiableList((List<Class>) Arrays.asList(new Class[] {
		Class.class,
		String.class,
		Date.class,
		java.sql.Date.class,
		BigDecimal.class
	}));
	
	
	public static boolean isBasicJavaTypeOrArray(Class<?> clazz) {
		Assert.notNull(clazz, "clazz required");
		
		boolean isPrimitive = isPrimitiveOrWrapper(clazz) || isPrimitiveArray(clazz) || isPrimitiveWrapperArray(clazz);
		
		if (isPrimitive) {
			return true;
		}
		
		if (BASIC_JAVA_TYPES.contains(clazz)) {
			return true;
		}
		
		if (clazz.isArray()) {
			Class<?> componentType = clazz.getComponentType();
			while (componentType.isArray()) {
				componentType = componentType.getComponentType();
			}
			return isSingleJavaType(componentType);
		}
		
		return false;
	}


	private static boolean isSingleJavaType(Class<?> clazz) {
		return BASIC_JAVA_TYPES.contains(clazz) || isPrimitiveOrWrapper(clazz);
	}
	
	
}
