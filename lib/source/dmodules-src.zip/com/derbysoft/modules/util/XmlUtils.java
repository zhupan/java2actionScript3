/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.util;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

/**
 * @since 2007-12-5
 * @author polics wang
 * @version $Id: XmlUtils.java,v 1.1 2007/12/05 06:47:29 wangzheng Exp $
 */
public abstract class XmlUtils {
	
	/**
	 * format a xml string to expected format xml string
	 * @param toFormat xml string to format
	 * @param outputEncoding output encoding, may be null
	 * @param indent whether to indent
	 * @return formated xml string
	 * @throws TransformerFactoryConfigurationError if can't create transformer
	 * @throws TransformerException if transform exception occured
	 */
	public static String formatXmlString(String toFormat, String outputEncoding, boolean indent) 
		throws TransformerFactoryConfigurationError, TransformerException {
		
		Transformer transformer = TransformerFactory.newInstance().newTransformer();
		String outIndent = indent ? "yes" : "no";
		transformer.setOutputProperty(OutputKeys.INDENT, outIndent);
		if (outputEncoding != null) {
			transformer.setOutputProperty(OutputKeys.ENCODING, outputEncoding);
		}
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		Source source = new StreamSource(new StringReader(toFormat));
		transformer.transform(source, result);
		return writer.toString();
	}
	
}
