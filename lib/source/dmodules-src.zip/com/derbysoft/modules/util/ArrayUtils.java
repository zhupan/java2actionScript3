/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.util;

import java.util.Collection;

import org.springframework.util.Assert;

/**
 * @since 2007-11-2
 * @author politics wang
 * @version $Id: ArrayUtils.java,v 1.2 2007/11/23 07:10:37 wangzheng Exp $
 */
public abstract class ArrayUtils {
	
	public static Object[] toArray(Object object) {
		Assert.notNull(object);
		
		//TODO process primitive 
		if (!object.getClass().isArray()) {
			Object[] array = new Object[0];
			
			if (Collection.class.isInstance(object)) {
				array = ((Collection<?>) object).toArray();
			} else {
				array = new Object[] {object};
			}			
			return array;
		}	
		
		return (Object[]) object;
	}
	
}
