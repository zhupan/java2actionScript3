/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.util.concurrent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * <code>ExecutorUtils</code> provide some useful method for async operation
 * @since 2008-1-3
 * @author polics wang
 * @author yk
 * @version $Id: ExecutorUtils.java,v 1.2 2008/01/24 03:32:01 wangzheng Exp $
 */
public abstract class ExecutorUtils {
	
	private static Log logger = LogFactory.getLog(ExecutorUtils.class);

	private static final long SINGLE_AWAIT_TIMEOUT = 1000L;
	
	/**
	 * Batch execute given tasks in given executor, 
	 * this method will eliminate <code>null</code> task result and
	 * ignore {@link InterruptedException} and {@link ExecutionException}
	 * @param <T> the result type of 
	 * @param executor the executor
	 * @param tasks the tasks
	 * @return batch execute results
	 * @see #batchExecute(Executor, Collection, boolean, boolean, boolean)
	 */
	public static <T> Collection<T> batchExecute(Executor executor, Collection<Callable<T>> tasks) {
		return batchExecute(executor, tasks, true, true, true);
	}
	
	/**
	 * Batch execute given tasks in given executor
	 * @param <T> the result type of 
	 * @param executor the executor
	 * @param tasks the tasks
	 * @param eliminateNullResult whether eliminate <code>null</code> task result
	 * @param ignoreInterruptedException whether ignore {@link InterruptedException}
	 * @param ignoreExecutionException whether ignore {@link ExecutionException}
	 * @return batch execute results
	 */
	public static <T> Collection<T> batchExecute(
		Executor executor, 
		Collection<Callable<T>> tasks, 
		boolean eliminateNullResult,
		boolean ignoreInterruptedException, 
		boolean ignoreExecutionException) {
	
		int taskSize = tasks.size();
		CompletionService<T> service = new ExecutorCompletionService<T>(executor);
		Collection<Future<T>> futures = new ArrayList<Future<T>>(taskSize);
		
		for (Callable<T> task : tasks) {
			Future<T> future = service.submit(task);
			futures.add(future);
		}

		Collection<T> results = new ArrayList<T>(taskSize);

		for (Future<T> future : futures) {
			try {
				T result = future.get();
				if (eliminateNullResult && result == null) {
					continue;
				}
				results.add(result);
			} catch (InterruptedException e) {
				if (ignoreInterruptedException) {
					logger.error(e.getMessage(), e);
				} else {
					Thread.currentThread().interrupt();
				}
			} catch (ExecutionException e) {
				if (ignoreExecutionException) {
					logger.error(e.getMessage(), e);
				} else {
					throw new RuntimeException("Execution Exception [" + e.getMessage() + "]", e);
				}
			}
		}
		
		return results;
	}
	
	public static List<Runnable> awaitShutdownNow(ExecutorService executorService) throws InterruptedException {
		List<Runnable> neverCommenced = executorService.shutdownNow();		
		while (!executorService.awaitTermination(SINGLE_AWAIT_TIMEOUT, TimeUnit.MILLISECONDS)) {
			logger.debug("Await for " + executorService + " termination ...");
		}
		return neverCommenced;
	}
	
	
	
}
