/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.util.concurrent;

import java.util.concurrent.ExecutorService;

/**
 * @since 2008-1-2
 * @author polics wang
 * @author yk
 * @version $Id: ExecutorServiceProvider.java,v 1.1 2008/01/02 08:32:14 wangzheng Exp $
 */
public interface ExecutorServiceProvider {
	
	ExecutorService getExecutorService();
	
}
