/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.util.concurrent;

import java.util.concurrent.ExecutorService;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

/**
 * Factory Bean for {@link ExecutorService}
 * @since 2008-1-4
 * @author polics wang
 * @author yk
 * @version $Id: ExecutorServiceFactoryBean.java,v 1.3 2008/01/04 08:54:28 wangzheng Exp $
 */
public class ExecutorServiceFactoryBean implements FactoryBean,
		InitializingBean, DisposableBean {

	private ExecutorServiceProvider executorServiceProvider;
	
	@Override
	public Object getObject() throws Exception {
		return executorServiceProvider.getExecutorService();
	}

	@Override
	public Class<ExecutorService> getObjectType() {
		return ExecutorService.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(executorServiceProvider, "executorServiceProvider required");
	}
	
	@Override
	public void destroy() throws Exception {
		executorServiceProvider.getExecutorService().shutdown();
	}

	public void setExecutorServiceProvider(ExecutorServiceProvider executorServiceProvider) {
		this.executorServiceProvider = executorServiceProvider;
	}


	
	

}
