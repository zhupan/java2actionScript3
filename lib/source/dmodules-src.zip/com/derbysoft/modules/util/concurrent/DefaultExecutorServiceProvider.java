/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.util.concurrent;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.scheduling.concurrent.CustomizableThreadFactory;

/**
 * @since 2008-1-2
 * @author polics wang
 * @author yk
 * @version $Id: DefaultExecutorServiceProvider.java,v 1.4 2008/01/24 07:16:00 wangzheng Exp $
 */
public class DefaultExecutorServiceProvider implements ExecutorServiceProvider, InitializingBean {

	private static transient Log logger = LogFactory.getLog(DefaultExecutorServiceProvider.class);
	
	public static final int DEFAULT_THREAD_POOL_SIZE = 20;
		
	private static ExecutorService cachedExecutorService;

	private int threadPoolSize = DEFAULT_THREAD_POOL_SIZE;

	
	@Override
	public ExecutorService getExecutorService() {		
		return getCachedExceutorService();
	}

	private synchronized ExecutorService getCachedExceutorService() {
		if (cachedExecutorService != null) {
			return cachedExecutorService;
		}
		ExceptionHandleSupportThreadFactory threadFactory = getThreadFactory();
		//TODO consider alternative implementor
		cachedExecutorService = Executors.newFixedThreadPool(threadPoolSize, threadFactory);
		return cachedExecutorService;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		getCachedExceutorService();
	}
	
	public void setThreadPoolSize(int threadPoolSize) {
		this.threadPoolSize = threadPoolSize;
	}

	private ExceptionHandleSupportThreadFactory getThreadFactory() {
		ThreadUncaughtExceptionHandler handler = new ThreadUncaughtExceptionHandler();	
		ExceptionHandleSupportThreadFactory factory = new ExceptionHandleSupportThreadFactory(handler);
		factory.setDaemon(true);
		factory.setThreadNamePrefix("DSwitch2 Worker ");
		return factory;
	}
		
	private static final class ExceptionHandleSupportThreadFactory extends CustomizableThreadFactory {
		
		private UncaughtExceptionHandler uncaughtExceptionHandler;
				
		public ExceptionHandleSupportThreadFactory(UncaughtExceptionHandler uncaughtExceptionHandler) {
			super();
			this.uncaughtExceptionHandler = uncaughtExceptionHandler;
		}

		/**
		 * @see org.springframework.scheduling.concurrent.CustomizableThreadFactory#newThread(java.lang.Runnable)
		 */
		public Thread newThread(Runnable runnable) {
			Thread thread = super.newThread(runnable);
			if (uncaughtExceptionHandler != null) {
				thread.setUncaughtExceptionHandler(uncaughtExceptionHandler);
			}
			return thread;
		}
		
	}
	
	
	private static final class ThreadUncaughtExceptionHandler implements UncaughtExceptionHandler {
		
		public void uncaughtException(Thread t, Throwable e) {
			if (logger.isInfoEnabled()) {
				logger.info("Exception in thread [" + t.getName() + "] ", e);
			}
		}
		
	}

}
