/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.util;

import java.lang.reflect.Method;

import org.apache.commons.lang.SystemUtils;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.util.ReflectionUtils;

/**
 * @since 2007-11-22
 * @author polics wang
 * @version $Id: ToStringStyleFactory.java,v 1.5 2007/12/05 07:00:44 wangzheng Exp $
 */
public abstract class ToStringStyleFactory {

	public static ToStringStyle getArrayMultiLineStyle() {
		ToStringStyle toStringStyle = ToStringStyle.MULTI_LINE_STYLE;
		String multilineSeparator = SystemUtils.LINE_SEPARATOR;
		
		Method getterMethod = ReflectionUtils.findMethod(
			toStringStyle.getClass(), 
			"getArraySeparator", 
			new Class[] {}
		);
		
		boolean getterAccessible = getterMethod.isAccessible();
		getterMethod.setAccessible(true);
		String currentArraySeprator = (String) ReflectionUtils.invokeMethod(getterMethod, toStringStyle, new Object[] {});
		getterMethod.setAccessible(getterAccessible);
		
		boolean setted = multilineSeparator == currentArraySeprator;
		
		if (!setted) {
			Method setterMethod = ReflectionUtils.findMethod(
				toStringStyle.getClass(), 
				"setArraySeparator", 
				new Class[] {String.class}
			);
			boolean setterAccessible = setterMethod.isAccessible();
			setterMethod.setAccessible(true);
			ReflectionUtils.invokeMethod(setterMethod, toStringStyle, new Object[] {multilineSeparator});	
			setterMethod.setAccessible(setterAccessible);
		}
		
		return toStringStyle;
	}

}
