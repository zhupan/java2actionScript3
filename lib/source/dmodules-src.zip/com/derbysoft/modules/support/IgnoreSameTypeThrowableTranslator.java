/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.support;


/**
 * @since 2007-11-12
 * @author politics wang
 * @version $Id: IgnoreSameTypeThrowableTranslator.java,v 1.4 2007/12/04 09:57:19 wangzheng Exp $
 */
public abstract class IgnoreSameTypeThrowableTranslator<T extends Throwable> 
	extends TranslatedTypeAwareThrowableTranslator<T> {
	

	/**
	 * Subclasses must overide this method to translate the throwable actually
	 * @param source the source throwable
	 * @return the transalted throwable
	 */
	protected abstract T doTranslate(Throwable source);
	
	@SuppressWarnings("unchecked")
	@Override
	public T translate(Throwable source) {
		if (source != null && translatedType != null && source.getClass().equals(translatedType)) {
			return (T) source;
		}
		return doTranslate(source);
	}
	

}
