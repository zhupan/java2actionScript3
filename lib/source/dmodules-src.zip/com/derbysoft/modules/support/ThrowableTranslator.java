/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.support;

/**
 * Strategy interface for translate a source {@link Throwable} to dest {@link Throwable}.
 * 
 * @since 2007-11-12
 * @author politics wang
 * @version $Id: ThrowableTranslator.java,v 1.2 2007/11/14 14:23:43 wangzheng Exp $
 */
public interface ThrowableTranslator<T extends Throwable> {
	
	/**
	 * translate the given source {@link Throwable} to dest {@link Throwable} 
	 * @param source the source <code>Throwable</code> 
	 * @return the translated <code>Throwable</code>
	 */
	T translate(Throwable source);
	
	/**
	 * get translated throwable type
	 * @return translated throwable type
	 */
	Class<T> getTranslatedType();
}
