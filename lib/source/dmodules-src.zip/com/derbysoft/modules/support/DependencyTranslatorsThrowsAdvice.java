/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.support;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.ThrowsAdvice;
import org.springframework.util.Assert;

import com.derbysoft.modules.patterns.cor.AbstractHandler;
import com.derbysoft.modules.patterns.cor.Handler;
import com.derbysoft.modules.patterns.cor.SequenceChainedHandlerFactory;

/**
 * @since 2007-11-12
 * @author politics wang
 * @version $Id: DependencyTranslatorsThrowsAdvice.java,v 1.2 2007/11/14 14:26:16 wangzheng Exp $
 */
public abstract class DependencyTranslatorsThrowsAdvice implements ThrowsAdvice {
	
	protected final transient Log logger = LogFactory.getLog(getClass());
	
	protected List<ThrowableTranslator<? extends Throwable>> translators 
		= new ArrayList<ThrowableTranslator<? extends Throwable>>();
	
	protected boolean loggerEnabled = true;
	
	/**
	 * Subclasses must overide this method to handle translated throwable
	 * @param tranlated the transnalted throwable
	 * @throws Throwable if the invocation encountered any errors
	 */
	protected abstract void handleTranslated(Throwable tranlated) throws Throwable;
	
	public void afterThrowing(Throwable t) throws Throwable {
		SequenceChainedHandlerFactory<Throwable> factory = new SequenceChainedHandlerFactory<Throwable>();
		
		for (ThrowableTranslator<? extends Throwable> translator : translators) {
			factory.addIndividalHandler(new ThrowableTranslatorHandlerAdapter(translator));
		}
		
		Throwable translated = factory.getChainedHandler().handleRequest(t);		
		logIfNecessary(t, translated);
		handleTranslated(translated);
	}
	
	private void logIfNecessary(Throwable t, Throwable translated) {
		if (isLoggerEnabled()) {
			logger.error("Throwable catched [" + ExceptionUtils.getFullStackTrace(t) 
							+ "], translate to [" + ExceptionUtils.getFullStackTrace(translated) + "]");
		}
	}
	
	public void setTranslators(List<ThrowableTranslator<? extends Throwable>> translators) {
		this.translators = translators;
	}
	
	public List<ThrowableTranslator<? extends Throwable>> getTranslators() {
		return translators;
	}

	public boolean isLoggerEnabled() {
		return loggerEnabled;
	}

	public void setLoggerEnabled(boolean loggerEnabled) {
		this.loggerEnabled = loggerEnabled;
	}

	
	/**
	 * inner adapter class for {@link Handler}
	 *
	 */
	private static final class ThrowableTranslatorHandlerAdapter extends AbstractHandler<Throwable> {

		private ThrowableTranslator<? extends Throwable> translator;
		
		public ThrowableTranslatorHandlerAdapter(ThrowableTranslator<? extends Throwable> translator) {
			super();
			Assert.notNull(translator, "translator required");
			this.translator = translator;
		}

		@Override
		protected Throwable doHandleRequest(Throwable source) throws Exception {
			return translator.translate(source);
		}

	}

}
