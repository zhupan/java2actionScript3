/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.support;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @since 2007-11-14
 * @author politics wang
 * @version $Id: TranslatedTypeAwareThrowableTranslator.java,v 1.1 2007/11/14 14:23:43 wangzheng Exp $
 */
public abstract class TranslatedTypeAwareThrowableTranslator<T extends Throwable> 
	implements ThrowableTranslator<T> {

	protected final transient Log logger = LogFactory.getLog(getClass());
	
	protected Class<T> translatedType;
	
	public TranslatedTypeAwareThrowableTranslator() {
		reflectionGetTypes();
	}
	
	@Override
	public Class<T> getTranslatedType() {
		return translatedType;
	}
	
	@SuppressWarnings("unchecked")
	private void reflectionGetTypes() {
		try {
			Type[] typeArguments = ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments();
			translatedType = (Class<T>) typeArguments[0];
	        logger.debug("Construt translator with translatedType [" + translatedType + "]");
		} catch (Exception e) {
			logger.info("Concreate translator [" + this + "] hasn't been parameterized, just ignore");
		}
	}
	



}
