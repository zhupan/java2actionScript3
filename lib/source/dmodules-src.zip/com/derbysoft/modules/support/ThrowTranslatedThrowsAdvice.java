/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.support;

/**
 * @since 2007-11-12
 * @author politics wang
 * @version $Id: ThrowTranslatedThrowsAdvice.java,v 1.2 2007/11/14 14:23:43 wangzheng Exp $
 */
public class ThrowTranslatedThrowsAdvice extends DependencyTranslatorsThrowsAdvice {

	@Override
	protected void handleTranslated(Throwable tranlated) throws Throwable {
		throw tranlated;
	}

}
