/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.spring.oxm.jaxb;

import javax.xml.bind.JAXBContext;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.oxm.jaxb.AbstractJaxbMarshaller;
import org.springframework.util.Assert;

/**
 * @since 2008-2-18
 * @author polics wang
 * @author yk
 * @version $Id: JAXBMarshallerBasedJAXBContextFactoryBean.java,v 1.1 2008/02/18 09:41:55 wangzheng Exp $
 */
public class JAXBMarshallerBasedJAXBContextFactoryBean implements FactoryBean, InitializingBean {
	
	private AbstractJaxbMarshaller jaxbMarshaller;
	
	@Override
	public Object getObject() throws Exception {
		return jaxbMarshaller.getJaxbContext();
	}

	@Override
	public Class<JAXBContext> getObjectType() {
		return JAXBContext.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(jaxbMarshaller, "jaxbMarshaller required");
	}

	public void setJaxbMarshaller(AbstractJaxbMarshaller jaxbMarshaller) {
		this.jaxbMarshaller = jaxbMarshaller;
	}	
	
}
