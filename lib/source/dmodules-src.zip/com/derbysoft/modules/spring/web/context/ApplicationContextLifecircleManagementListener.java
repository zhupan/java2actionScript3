/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.spring.web.context;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.util.Assert;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * @since 2008-2-21
 * @author polics wang
 * @author yk
 * @version $Id$
 */
public class ApplicationContextLifecircleManagementListener implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent event) {
		getConfigurableApplicationContext(event).start();
	}

	private ConfigurableApplicationContext getConfigurableApplicationContext(ServletContextEvent event) {
		ApplicationContext context = 
			WebApplicationContextUtils.getRequiredWebApplicationContext(event.getServletContext());
		Assert.isInstanceOf(ConfigurableApplicationContext.class, context, "Oh my god, which spring version are you using??? ");
		ConfigurableApplicationContext configurableApplicationContext = (ConfigurableApplicationContext) context;
		return configurableApplicationContext;
	}

	@Override
	public void contextDestroyed(ServletContextEvent event) {
		getConfigurableApplicationContext(event).stop();
	}
	
}
