/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.spring.context;

import org.springframework.context.ApplicationContext;
import org.springframework.util.Assert;

/**
 * @since 2008-1-14
 * @author polics wang
 * @author yk
 * @version $Id: ApplicationContextHolder.java,v 1.1 2008/01/14 09:25:34 wangzheng Exp $
 */
public abstract class ApplicationContextHolder {
	
	private static ApplicationContext applicationContext;
	
	public static void setApplicationContext(ApplicationContext applicationContext) {
		ApplicationContextHolder.applicationContext = applicationContext;
	}

	public static ApplicationContext getApplicationContext() {
    	Assert.notNull(
    		applicationContext, 
    		"spring applicationContext is null, container start failed or initializing"
    	);
    	return applicationContext;
	}
	
	
}
