package com.derbysoft.modules.spring.beans.factory;

import org.springframework.beans.factory.InitializingBean;

import com.derbysoft.modules.core.BaseRuntimeExceptionTranslator;

public abstract class InitializingBeanUtils {

	public static void afterPropertiesSet(InitializingBean initializingBean) {
		try {
			initializingBean.afterPropertiesSet();
		} catch (Exception e) {
			throw new BaseRuntimeExceptionTranslator().translate(e);
		}
	}

}
