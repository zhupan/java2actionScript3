/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.spring.io.util;

import java.lang.reflect.Method;
import java.util.Properties;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.support.PropertiesLoaderSupport;
import org.springframework.util.ReflectionUtils;

/**
 * utility class for {@link PropertiesLoaderSupport}, typically a {@link PropertyPlaceholderConfigurer}
 * @see PropertyPlaceholderConfigurer
 * @since 2007-11-22
 * @author polics wang
 * @version $Id: PropertiesLoaderSupportUtils.java,v 1.4 2007/12/05 07:00:44 wangzheng Exp $
 */
public abstract class PropertiesLoaderSupportUtils {
	
	private static Properties cachedProperties = null;
	
	/**
	 * get merged spring PropertyPlaceholderConfigurer properties
	 * @param support the PropertyPlaceholderConfigurer
	 * @return merged properties
	 */
	public static synchronized Properties getMergedSpringConfigProperties(PropertiesLoaderSupport support) {
		if (cachedProperties != null) {
			return cachedProperties;
		}

		Method method = ReflectionUtils.findMethod(
			support.getClass(), 
			"mergeProperties", 
			new Class[] {}
		);
		
		boolean accessible = method.isAccessible();
		method.setAccessible(true);
					
		try {
			cachedProperties = (Properties) method.invoke(support, new Object[]{});
		} catch (Exception ex) {
			ReflectionUtils.handleReflectionException(ex);
		} 
		
		method.setAccessible(accessible);		
		return cachedProperties;
	}
	
	
	
}
