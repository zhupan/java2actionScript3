/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch
 */
package com.derbysoft.modules.config;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.MapConfiguration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.support.PropertiesLoaderSupport;
import org.springframework.util.ClassUtils;

import com.derbysoft.modules.core.BaseRuntimeExceptionTranslator;
import com.derbysoft.modules.spring.io.util.PropertiesLoaderSupportUtils;

/**
 * @since 2007-4-4
 * @author 王政
 * @version $Id: DefaultConfigurationCenter.java,v 1.2 2007/12/03 02:14:12 wangzheng Exp $
 */
public class DefaultConfigurationCenter implements ConfigurationCenter, InitializingBean {
	
	private static transient Log logger = LogFactory.getLog(DefaultConfigurationCenter.class);
	
	private Map<String, String> xmlFiles = new LinkedHashMap<String, String>();
	
	private Map<String, String> propertyFiles = new LinkedHashMap<String, String>();
	
	private List<Configuration> configurationBeans = new ArrayList<Configuration>();
	
	private PropertiesLoaderSupport springPropertiesLoader;
	
	private CompositeConfiguration cc;
	
	/**
	 * @param propertyFiles the propertyFiles to set
	 */
	public void setPropertyFiles(Map<String, String> propertyFiles) {
		this.propertyFiles = propertyFiles;
	}

	/**
	 * @param xmlFiles the xmlFiles to set
	 */
	public void setXmlFiles(Map<String, String> xmlFiles) {
		this.xmlFiles = xmlFiles;
	}
	
	/**
	 * @param configurationBeans the configurationBeans to set
	 */
	public void setConfigurationBeans(List<Configuration> configurationBeans) {
		this.configurationBeans = configurationBeans;
	}
	
	public void setSpringPropertiesLoader(PropertiesLoaderSupport springPropertiesLoader) {
		this.springPropertiesLoader = springPropertiesLoader;
	}

	/**
	 * synchronized 的原因是 {@link CompositeConfiguration} 不是 Thread Safe 的
	 * @see CompositeConfiguration
	 * @see com.derby.application.config.ConfigurationCenter#getConfiguration()
	 */
	public synchronized Configuration getConfiguration() {
		return cc;
	}

	private Configuration loadConfiguration() throws RuntimeException {
		cc = new CompositeConfiguration();		
		try {
			addXmlConfigurations();
			addPropertyConfigurations();
			addConfigurationBeans();
			addSpringPropertiesLoader();
		} catch (ConfigurationException e) {
			String errorMessage = "Error during load configuration : " + e;
			if (logger.isDebugEnabled()) {
				logger.debug(errorMessage, e);
			}
			throw new BaseRuntimeExceptionTranslator().translate(e);
		}
		return cc;
	}

	private void addSpringPropertiesLoader() {
		if (springPropertiesLoader != null) {
			Properties springProperties = 
				PropertiesLoaderSupportUtils.getMergedSpringConfigProperties(springPropertiesLoader);
			cc.addConfiguration(new MapConfiguration(springProperties));
		}
	}

	private void addConfigurationBeans() {
		for (Configuration configuration : configurationBeans) {
			cc.addConfiguration(configuration);
		}
	}

	private void addPropertyConfigurations() throws ConfigurationException {
		for (Map.Entry<String, String> entry : propertyFiles.entrySet()) {
			String propertyFilePath = entry.getKey();
			String encoding = entry.getValue();
			PropertiesConfiguration configuration =
		            new PropertiesConfiguration(ClassUtils.getDefaultClassLoader().getResource(propertyFilePath));
			if (StringUtils.isNotBlank(encoding)) {
				configuration.setEncoding(encoding);
			}
			cc.addConfiguration(configuration);
		}
	}

	private void addXmlConfigurations() throws ConfigurationException {
		for (Map.Entry<String, String> entry : xmlFiles.entrySet()) {
			String xmlFilePath = entry.getKey();
			String encoding = entry.getValue();
			XMLConfiguration configuration =
		            new XMLConfiguration(ClassUtils.getDefaultClassLoader().getResource(xmlFilePath));
			if (StringUtils.isNotBlank(encoding)) {
				configuration.setEncoding(encoding);
			}
			cc.addConfiguration(configuration);
		}
	}

	public void reload() {
		loadConfiguration();
	}

	
	public void afterPropertiesSet() throws Exception {
		loadConfiguration();
	}

}
