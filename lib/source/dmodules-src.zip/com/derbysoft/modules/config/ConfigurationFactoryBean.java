/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.config;

import org.apache.commons.configuration.Configuration;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

/**
 * @since 2007-11-29
 * @author polics wang
 * @version $Id: ConfigurationFactoryBean.java,v 1.1 2007/11/29 13:31:04 wangzheng Exp $
 */
public class ConfigurationFactoryBean implements FactoryBean, InitializingBean {
	
	private ConfigurationCenter configurationCenter;
	
	@Override
	public Object getObject() throws Exception {
		return configurationCenter.getConfiguration();
	}

	@Override
	public Class<Configuration> getObjectType() {
		return Configuration.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

	public void setConfigurationCenter(ConfigurationCenter configurationCenter) {
		this.configurationCenter = configurationCenter;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(configurationCenter, "configurationCenter required");
	}

}
