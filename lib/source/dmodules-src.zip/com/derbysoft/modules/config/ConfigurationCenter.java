/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch
 */
package com.derbysoft.modules.config;

import org.apache.commons.configuration.Configuration;

/**
 * <code>ConfigurationCenter</code> 是 dswitch 的配置中心, 目前使用
 * commons-configuration 实现, 此接口只是一个简单的 facade, 默认实现是
 * {@link DefaultConfigurationCenter}
 * 
 * @see Configuration
 * @see DefaultConfigurationCenter
 * @since 2007-4-4
 * @author 王政
 * @version $Id: ConfigurationCenter.java,v 1.1 2007/11/29 13:31:04 wangzheng Exp $
 */
public interface ConfigurationCenter {
	
	/**
	 * 得到全局 Configuration 对象
	 * @return the configuration
	 */
	Configuration getConfiguration();
	
	/**
	 * 重新装载配置, 业务代码不应该调用此方法
	 *
	 */
	void reload();
	
}
