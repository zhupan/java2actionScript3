/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.patterns.cor;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @since 2007-11-2
 * @author politics wang
 * @version $Id: PassThroughHandler.java,v 1.2 2007/11/02 06:29:34 wangzheng Exp $
 */
public class PassThroughHandler<T> extends AbstractHandler<T> {

	private static transient Log logger = LogFactory.getLog(PassThroughHandler.class);
	
	@Override
	protected T doHandleRequest(T request) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("Simple pass though the request [" + request + "]");
		}
		return request;
	}

	

}
