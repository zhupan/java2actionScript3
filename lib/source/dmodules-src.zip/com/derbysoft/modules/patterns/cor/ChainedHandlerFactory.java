/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.patterns.cor;

/**
 * Convenient factory of {@link Handler}
 * @see PassThroughHandler
 * @since 2007-11-2
 * @author politics wang
 * @version $Id: ChainedHandlerFactory.java,v 1.1 2007/11/02 06:24:30 wangzheng Exp $
 */
public interface ChainedHandlerFactory<T> {
	
	/**
	 * get chained handler, if no handlers specified, 
	 * return {@link PassThroughHandler} 
	 * @return the handler, nevel null
	 * @see PassThroughHandler
	 */
	Handler<T> getChainedHandler();
	
}
