/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.patterns.cor;

/**
 * Strategy interface of 
 * <a href="http://www.tml.tkk.fi/~pnr/GoF-models/html/Chain-of-responsibility.html">GOF Chain of responsibility pattern</a>
 * @since 2007-10-31
 * @author politics wang
 * @version $Id: Handler.java,v 1.2 2007/11/14 14:35:29 wangzheng Exp $
 */
public interface Handler<T> {
	
	Handler<T> getSuccessor();
	
	void setSuccessor(Handler<T> successor);
	
	T handleRequest(T request) throws Exception;
	
}
