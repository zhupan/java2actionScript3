/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.patterns.cor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


/**
 * @since 2007-11-2
 * @author politics wang
 * @version $Id: SequenceChainedHandlerFactory.java,v 1.2 2007/11/02 06:28:34 wangzheng Exp $
 */
public class SequenceChainedHandlerFactory<T> implements ChainedHandlerFactory<T> {
	
	private List<Handler<T>> individalHandlers = new ArrayList<Handler<T>>();
	
	/**
	 * @param handlers the handlers to set
	 */
	public void setIndividalHandlers(List<Handler<T>> handlers) {
		this.individalHandlers = handlers;
	}
	
	public void addIndividalHandler(Handler<T> individalHandler) {
		if (individalHandlers == null) {
			individalHandlers = new ArrayList<Handler<T>>();
		}
		individalHandlers.add(individalHandler);
	}
	
	@Override
	public Handler<T> getChainedHandler() {
		if (individalHandlers.isEmpty()) {
			return new PassThroughHandler<T>();
		}
		
		Iterator<Handler<T>> iterator = individalHandlers.iterator();
		Handler<T> first = iterator.next();
		Handler<T> current = first;
		
		while (iterator.hasNext()) {
			Handler<T> next = iterator.next();
			current.setSuccessor(next);
			current = next;
		}
		
		return first;
	}
	


}
