/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.patterns.cor;

/**
 * @since 2007-10-31
 * @author politics wang
 * @version $Id: AbstractHandler.java,v 1.2 2007/11/14 14:23:43 wangzheng Exp $
 */
public abstract class AbstractHandler<T> implements Handler<T> {
	
	protected Handler<T> successor;
	
	protected abstract T doHandleRequest(T request) throws Exception;
	
	@Override
	public final T handleRequest(T request) throws Exception {
		T result = doHandleRequest(request);
		if (successor != null) {
			return successor.handleRequest(result);
		}
		return result;
	}

	/**
	 * @return the next
	 */
	public Handler<T> getSuccessor() {
		return successor;
	}


	/**
	 * @param next the next to set
	 */
	public void setSuccessor(Handler<T> next) {
		this.successor = next;
	}


}
