package com.derbysoft.modules.cache.memcached;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.List;

import net.spy.memcached.AddrUtil;
import net.spy.memcached.MemcachedClient;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;


public class DefaultMemcachedClientFactory implements MemcachedClientFactory, 
	InitializingBean {
	
	private static Log logger = LogFactory.getLog(DefaultMemcachedClientFactory.class);
	
	private static MemcachedClient memcachedClient;
		
	private static final int DEFAULT_PORT = 11211;
	
	private String serverHost;
	
	private int port = DEFAULT_PORT;
			
	@Override
	public synchronized MemcachedClient getMemcachedClient() {
		if (memcachedClient == null) {
			initialize();
		}
		return memcachedClient;
	}
	
	private synchronized void initialize() {
		String url = serverHost + ":" + port;
		List<InetSocketAddress> addresses = AddrUtil.getAddresses(url);
		try {
			memcachedClient = new MemcachedClient(addresses);
			logger.info("Successful Create MemcachedClient [" + url + "]");
		} catch (IOException e) {
			throw new RuntimeException("Can't connect to memcache [" + e.getMessage() + "]", e);
		}
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(serverHost, "serverHost required");
	}

	public void setServerHost(String serverHost) {
		this.serverHost = serverHost;
	}

	public void setPort(int port) {
		this.port = port;
	}
	
	

}
