/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.cache.memcached.support;

import net.spy.memcached.MemcachedClient;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;

import com.derbysoft.modules.cache.memcached.MemcachedOperations;

/**
 * @since 2008-3-6
 * @author politics wang
 * @version $Id$
 */
public class MemcachedTemplate implements MemcachedOperations {
	
	private static Log logger = LogFactory.getLog(MemcachedTemplate.class);
	
	private MemcachedClient memcachedClient;
	
	private int expiration;
	
	private boolean memcachedEnabled;
	
	public MemcachedTemplate(boolean memcachedEnabled, MemcachedClient memcachedClient, int expiration) {
		super();
		this.memcachedEnabled = memcachedEnabled;
		if (memcachedEnabled) {
			Assert.notNull(memcachedClient, "memcachedClient required");			
			this.memcachedClient = memcachedClient;
			this.expiration = expiration;			
		}
	}

	@Override
	public synchronized void delete(String key) {
		if (memcachedEnabled) {
			if (logger.isDebugEnabled()) {
				logger.debug("Memcached key deleted [" + key + "]");
			}
			memcachedClient.delete(key);			
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public synchronized <T> T get(String key, Class<T> expectType) {
		if (memcachedEnabled) {
			Object cached = memcachedClient.get(key);
			
			if (cached != null) {
				if (logger.isDebugEnabled()) {
					logger.debug("Memcached hitted by key [" + key + "]");
				}
			}
			
			try {
				return (T) cached;
			} catch (ClassCastException ex) {
				throw new RuntimeException(
					"Can't cast cached to expected type, cause [" + ex.getMessage() + "]", 
					ex
				);
			}			
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public synchronized <T> void put(String key, T value) {
		if (memcachedEnabled) {
			T cached = (T) get(key, null);
			if (cached == null) {
				if (logger.isDebugEnabled()) {
					logger.debug("Add key [" + key + "] value [" + value + "] to memcached");
				}
				memcachedClient.add(key, expiration, value);
			} else {
				if (logger.isDebugEnabled()) {
					logger.debug("Set key [" + key + "] value [" + value + "] to memcached");
				}
				memcachedClient.set(key, expiration, value);
			}			
		}
	}

}
