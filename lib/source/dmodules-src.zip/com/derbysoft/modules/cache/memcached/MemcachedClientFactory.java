package com.derbysoft.modules.cache.memcached;

import net.spy.memcached.MemcachedClient;


public interface MemcachedClientFactory {
	
	MemcachedClient getMemcachedClient();
	
}
