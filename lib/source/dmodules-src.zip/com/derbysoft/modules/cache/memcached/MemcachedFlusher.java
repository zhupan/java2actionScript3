/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.cache.memcached;

import java.util.concurrent.Future;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

/**
 * @since 2008-3-10
 * @author politics wang
 * @version $Id$
 */
public class MemcachedFlusher implements InitializingBean {
	
	private static Log logger = LogFactory.getLog(MemcachedFlusher.class);
	
	private MemcachedClientFactory memcachedClientFactory;

	private void flush() {
		logger.info("Pre flush memcached...");
		Future<Boolean> future = memcachedClientFactory.getMemcachedClient().flush();
		try {
			Boolean result = future.get();
			String message = result.booleanValue() ? "Success" : "Failed";
			logger.info("Flush memcached " + message);
		} catch (Exception e) {
			logger.error("Flush memcached failed [ " + e.getLocalizedMessage() + " ]", e);
		}
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(memcachedClientFactory, " memcachedClientFactory required ");
		flush();
	}

	public void setMemcachedClientFactory(MemcachedClientFactory memcachedClientFactory) {
		this.memcachedClientFactory = memcachedClientFactory;
	}

	
	
}
