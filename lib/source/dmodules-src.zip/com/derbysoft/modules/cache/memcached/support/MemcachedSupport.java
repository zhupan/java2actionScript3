/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.cache.memcached.support;

import net.spy.memcached.MemcachedClient;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import com.derbysoft.modules.cache.memcached.MemcachedClientFactory;

/**
 * @since 2008-3-5
 * @author politics wang
 * @version $Id$
 */
public abstract class MemcachedSupport implements InitializingBean {

	/** 1 hour */
	protected static final int DEFAULT_EXPIRATION = 3600;
	
	protected boolean memcachedEnabled = true;
	
	protected int expiration = DEFAULT_EXPIRATION;
	
	protected MemcachedClientFactory memcachedClientFactory;
	
	protected MemcachedTemplate getMemcachedTemplate() {
		MemcachedTemplate template = new MemcachedTemplate(memcachedEnabled, getMemcachedClient(), expiration);
		return template;
	}
	
	private MemcachedClient getMemcachedClient() {
		return memcachedClientFactory.getMemcachedClient();
	}

	protected void initBean() throws Exception {
	}

	@Override
	public final void afterPropertiesSet() throws Exception {
		Assert.notNull(memcachedClientFactory, "memcachedClientFactory required");
		initBean();
	}

	public void setMemcachedEnabled(boolean memcachedEnabled) {
		this.memcachedEnabled = memcachedEnabled;
	}

	public void setExpiration(int expiration) {
		this.expiration = expiration;
	}

	public void setMemcachedClientFactory(MemcachedClientFactory memcachedClientFactory) {
		this.memcachedClientFactory = memcachedClientFactory;
	}


	
}
