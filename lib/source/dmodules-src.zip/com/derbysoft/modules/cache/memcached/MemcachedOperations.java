/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.cache.memcached;


/**
 * @since 2008-3-6
 * @author politics wang
 * @version $Id$
 */
public interface MemcachedOperations {
	
	/**
	 * Put {@link T} to cache, update if key exists
	 * @param key the cache key
	 * @param currencyRate the {@link T}
	 */
	<T> void put(String key, T value);
	
	/**
	 * Get {@link T} from cache, return <code>null</code> if not found
	 * @param key the cache key
	 * @param expectType expect return type
	 * @return cached {@link T}, <code>null</code> if not found
	 */
	<T> T get(String key, Class<T> expectType);
	
	/**
	 * Delete cache by specified key
	 * @param key the cache key
	 */
	void delete(String key);
	
}
