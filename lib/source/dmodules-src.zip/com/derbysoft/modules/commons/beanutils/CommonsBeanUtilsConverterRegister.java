/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.commons.beanutils;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.BigDecimalConverter;
import org.apache.commons.beanutils.converters.BigIntegerConverter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

/**
 * @since 2008-1-4
 * @author polics wang
 * @author yk
 * @version $Id: CommonsBeanUtilsConverterRegister.java,v 1.4 2008/01/24 03:32:01 wangzheng Exp $
 */
public class CommonsBeanUtilsConverterRegister implements InitializingBean, DisposableBean {
	
	private static Log logger = LogFactory.getLog(CommonsBeanUtilsConverterRegister.class);
	
	public static void registerConvertersWithDefaultValue() {
		logger.info("Register converters with default value");
		ConvertUtils.register(new BigIntegerConverter(null), BigInteger.class);
		ConvertUtils.register(new BigDecimalConverter(null), BigDecimal.class);
		//TODO add other required converters
	}
	
	public static void deregister() {
		logger.info("Deregister converters");
		ConvertUtils.deregister();
	}
	

	@Override
	public void afterPropertiesSet() throws Exception {
		registerConvertersWithDefaultValue();
	}

	@Override
	public void destroy() throws Exception {
		deregister();
	}

}
