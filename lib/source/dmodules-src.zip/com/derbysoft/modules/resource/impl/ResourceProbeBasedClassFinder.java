/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.resource.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;

import com.derbysoft.modules.resource.ClassFinder;
import com.derbysoft.modules.resource.ResourceProbe;



/**
 * @since 2008-1-3
 * @author polics wang
 * @author yk
 * @version $Id: ResourceProbeBasedClassFinder.java,v 1.1 2008/01/03 11:54:13 wangzheng Exp $
 */
public class ResourceProbeBasedClassFinder implements ClassFinder,
		InitializingBean {
	
	private static transient Log logger = LogFactory.getLog(ResourceProbeBasedClassFinder.class);
	
	public static final String DOT = ".";
	public static final String SLASH = "/";
	
	private ResourceProbe resourceProbe = new AntResourceProbe();
	
	@Override
	public Collection<Class<?>> findClass(String classPattern) {
		return findClass(classPattern, null);
	}

	@Override
	public Collection<Class<?>> findClass(String classPattern, String elimination) {
		String[] searchedClassFiles = resourceProbe.search(classPattern, elimination);
		List<String> classNames = new ArrayList<String>(searchedClassFiles.length);
		
		for (int i = 0; i < searchedClassFiles.length; i++) {
			String className = StringUtils.replace(searchedClassFiles[i], SLASH, DOT);
			int classSuffixIndex = className.indexOf(".class");
			Assert.isTrue(classSuffixIndex != -1);
			String classNameWithoutSuffix = className.substring(0, classSuffixIndex);
			classNames.add(classNameWithoutSuffix);
		}	
		
		Collection<Class<?>> findedClasses = new ArrayList<Class<?>>(classNames.size());
		
		for (String className : classNames) {
			try {
				Class<?> clazz = ClassUtils.getDefaultClassLoader().loadClass(className);
				findedClasses.add(clazz);
			} catch (ClassNotFoundException e) {
				if (logger.isErrorEnabled()) {
					logger.error("Class [" + className + "] not found, ignore it");
				}
			}			
		}
				
		return findedClasses;
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(resourceProbe, "resourceProbe required");
	}

	public void setResourceProbe(ResourceProbe resourceProbe) {
		this.resourceProbe = resourceProbe;
	}

	
	
}
