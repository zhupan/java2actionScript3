/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.resource;

import java.util.Collection;

/**
 * @since 2008-1-3
 * @author polics wang
 * @author yk
 * @version $Id: ClassFinder.java,v 1.1 2008/01/03 11:54:13 wangzheng Exp $
 */
public interface ClassFinder {
	
	Collection<Class<?>> findClass(String classPattern);
	
	Collection<Class<?>> findClass(String classPattern, String elimination);
	
}
