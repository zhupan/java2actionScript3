/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.core;

import com.derbysoft.modules.support.IgnoreSameTypeThrowableTranslator;

/**
 * @since 2007-11-28
 * @author polics wang
 * @version $Id: BaseRuntimeExceptionTranslator.java,v 1.3 2007/12/03 01:51:52 xuewei Exp $
 */
public class BaseRuntimeExceptionTranslator extends
		IgnoreSameTypeThrowableTranslator<BaseRuntimeException> {

	@Override
	protected BaseRuntimeException doTranslate(Throwable source) {
		return new BaseRuntimeException(source.getMessage(), source);
	}

}
