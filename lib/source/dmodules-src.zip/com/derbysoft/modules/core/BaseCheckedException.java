/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.core;

/**
 * top level checked exception
 * 
 * @since 2007-9-28
 * @author politics wang
 * @version $Id: BaseCheckedException.java,v 1.4 2007/12/03 01:51:52 xuewei Exp $
 */
public class BaseCheckedException extends Exception {

	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = -6972014570510725666L;

	public BaseCheckedException(String message) {
		super(message);
	}

	public BaseCheckedException(Throwable cause) {
		super(cause);
	}
	
	public BaseCheckedException(String message, Throwable cause) {
		super(message, cause);
	}
	
}
