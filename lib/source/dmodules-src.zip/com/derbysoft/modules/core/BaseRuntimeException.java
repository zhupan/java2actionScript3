/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.core;

/**
 * top level runtime exception
 * 
 * @since 2007-9-28
 * @author politics wang
 * @version $Id: BaseRuntimeException.java,v 1.4 2007/12/03 01:51:52 xuewei Exp $
 */
public class BaseRuntimeException extends RuntimeException {

	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = -5648173898608882157L;

	public BaseRuntimeException(String message) {
		super(message);
	}

	public BaseRuntimeException(Throwable cause) {
		super(cause);
	}

	public BaseRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}	
	
}
