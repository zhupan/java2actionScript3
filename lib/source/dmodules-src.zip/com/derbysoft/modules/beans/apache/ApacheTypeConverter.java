/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.beans.apache; 

import org.apache.commons.beanutils.ConvertUtils;

import com.derbysoft.modules.beans.TypeConverter;

/**
 * @since 2007-11-2
 * @author politics wang
 * @version $Id: ApacheTypeConverter.java,v 1.1 2007/11/02 09:54:37 wangzheng Exp $
 */
public class ApacheTypeConverter implements TypeConverter {

	@Override
	public Object convertValue(Class<?> toType, Object orig) {
		return ConvertUtils.convert(orig);
	}

}
