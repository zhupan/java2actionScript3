/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.beans.xwork;

import com.derbysoft.modules.beans.TypeConverter;
import com.opensymphony.xwork2.util.XWorkConverter;

/**
 * @since 2007-11-2
 * @author politics wang
 * @version $Id: XWorkTypeConverter.java,v 1.1 2007/11/02 09:54:37 wangzheng Exp $
 */
public class XWorkTypeConverter implements TypeConverter {

	@Override
	public Object convertValue(Class<?> toType, Object orig) {
		XWorkConverter converter = XWorkConverter.getInstance();
		return converter.convertValue(null, orig, toType);
	}



}
