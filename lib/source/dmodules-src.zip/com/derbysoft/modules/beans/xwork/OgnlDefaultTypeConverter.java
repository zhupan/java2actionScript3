/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.beans.xwork;

import ognl.DefaultTypeConverter;

import com.derbysoft.modules.beans.TypeConverter;

/**
 * @since 2007-11-2
 * @author politics wang
 * @version $Id: OgnlDefaultTypeConverter.java,v 1.1 2007/11/02 09:54:37 wangzheng Exp $
 */
public class OgnlDefaultTypeConverter implements TypeConverter {

	@Override
	public Object convertValue(Class<?> toType, Object orig) {
		DefaultTypeConverter converter = new DefaultTypeConverter();
		return converter.convertValue(null, orig, toType);
	}



}
