/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.beans;

/**
 * Type converter interface for various implemention
 * @since 2007-11-2
 * @author politics wang
 * @version $Id: TypeConverter.java,v 1.1 2007/11/02 09:54:37 wangzheng Exp $
 */
public interface TypeConverter {
	
	Object convertValue(Class<?> toType, Object orig);

}
