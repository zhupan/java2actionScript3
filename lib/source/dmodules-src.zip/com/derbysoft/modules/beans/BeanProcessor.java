/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.beans;

/**
 * @since 2008-1-9
 * @author polics wang
 * @author yk
 * @version $Id: BeanProcessor.java,v 1.1 2008/01/09 13:46:11 wangzheng Exp $
 */
public interface BeanProcessor {

	<T> T deepClone(T orignal);
	
	void deepCopy(Object dest, Object orig);
	
}
