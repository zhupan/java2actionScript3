/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.coheg.com.cn
 *
 * Project framework
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.CriteriaQuery;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Junction;
import org.hibernate.engine.TypedValue;
import org.springframework.util.Assert;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Relation;

/**
 * 将多个 Criterion 合并成一个 Criterion 的 Expression, 与 {@link Junction} 不同的是
 * 每个子 Expression 都可以有不同的连接符 and 或 or
 * @see Junction
 * @see Conjunction
 * @see Disjunction
 * @since 2006-8-20
 * @author polics wang
 * @version $Id: MultiCriterionsExpression.java,v 1.2 2007/11/05 11:43:40 wangzheng Exp $
 */
public class MultiCriterionsExpression implements Criterion {
	
	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = -6153626155195309794L;

	private Criterion[] criterions = new Criterion[0];
	
	private Relation[] ops = new Relation[0];
	
	public MultiCriterionsExpression(List<Criterion> criterions, List<Relation> ops) {
		Assert.notNull(criterions, " criterions required. ");
		Assert.notNull(ops, " ops required. ");
		Assert.isTrue(criterions.size() == ops.size());
		this.criterions = criterions.toArray(new Criterion[0]);
		this.ops = ops.toArray(new Relation[0]);
	}
	
	public TypedValue[] getTypedValues(Criteria criteria, CriteriaQuery criteriaQuery) 
		throws HibernateException {
		
		List<TypedValue> result = new ArrayList<TypedValue>();
		
		for (int i = 0; i < criterions.length; i++) {
			TypedValue[] typedValues = criterions[i].getTypedValues(criteria, criteriaQuery);
			for (int j = 0; j < typedValues.length; j++) {
				result.add(typedValues[j]);
			}
		}
		
		return result.toArray(new TypedValue[0]);
	}

	public String toSqlString(Criteria criteria, CriteriaQuery criteriaQuery)
		throws HibernateException {
		StringBuffer buffer = new StringBuffer();
		buffer.append(" ( ");
		for (int i = 0; i < criterions.length; i++) {
			if (i != 0) {
				buffer.append(ops[i] == null ? Relation.getDefault() : ops[i]);
			}			
			buffer.append(" ");
			buffer.append(criterions[i].toSqlString(criteria, criteriaQuery));
			buffer.append(" ");
		}
		buffer.append(" ) ");
		return buffer.toString();
	}

}
