/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.derbysoft.modules.persistence.hibernate3.dao.HibernateQueryProvider;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionContext;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Paginater;

/**
 * @since 2007-10-30
 * @author politics wang
 * @version $Id: DefaultHibernateQueryProvider.java,v 1.3 2007/11/19 05:25:38 wangzheng Exp $
 */
public class DefaultHibernateQueryProvider extends HibernateDaoSupport
		implements HibernateQueryProvider {

	@SuppressWarnings("unchecked")
	@Override
	public <T> List<T> findByCondition(ConditionContext conditionContext, Class<T> clazz) {
		DetachedCriteria criteria = conditionContext.getCriteria(clazz);
		return getHibernateTemplate().findByCriteria(criteria);
	}

	@Override
	public <T> Paginater<T> paginate(ConditionContext conditionContext, Class<T> clazz) {
		DetachedCriteria criteria = conditionContext.getCriteria(clazz);
		return getPaginateSupportHibernateTemplate().paginate(criteria, conditionContext.getPaginater());
	}
	
	private PaginateSupportHibernateTemplate getPaginateSupportHibernateTemplate() {
		return new PaginateSupportHibernateTemplate(getSessionFactory());
	}

	
}
