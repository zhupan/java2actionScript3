/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.ObjectRetrievalFailureException;

/**
 * <p>Top level generic dao interface, 
 * most code taken from <a href="http://www.hibernate.org/328.html">hibernate site</a>,
 * default implemention is {@link HibernateGenericDaoSupport}
 * 
 * <p>Consider {@link HibernateQueryProvider} for a more comprehensive suite 
 * of query and paginater operations. 
 * 
 * @see HibernateGenericDaoSupport
 * @see HibernateQueryProvider
 * @param <T> the entity type
 * @param <ID> the entity id type
 * @since 2007-10-23
 * @author politics wang
 * @version $Id: GenericDao.java,v 1.4 2007/12/05 05:13:41 wangzheng Exp $
 */
public interface GenericDao<T, ID extends Serializable> {
	
	/**
	 * load object by id, throw {@link ObjectRetrievalFailureException} if entity not exist
	 * @see #load(Serializable, boolean)
	 * @see #get(Serializable)
	 * @param id eneity id
	 * @return loaded entity
	 * @throws ObjectRetrievalFailureException if entity not exist
	 */
	T load(ID id) throws ObjectRetrievalFailureException;
	
	/**
	 * load object by id, perform a lock operation on entity if <code>lock</code> is true, 
	 * throw {@link ObjectRetrievalFailureException} if entity not exist
	 * @see #load(Serializable)
	 * @see #get(Serializable)
	 * @param id eneity id
	 * @param lock whether to lock entity 
	 * @return loaded entity
	 * @throws ObjectRetrievalFailureException if entity not exist
	 */
	T load(ID id, boolean lock) throws ObjectRetrievalFailureException;
	
	/**
	 * get object by id, return <code>null</code> if entity not exist
	 * @param id the entity id
	 * @return loaded entity, <code>null</code> if entity not exist
	 */
	T get(ID id);
	
	/**
	 * transform a entity object to persistent state  
	 * @param entity the entity object
	 * @return persistent entity object
	 */
    T makePersistent(T entity);
    
    /**
     * transform a entity object to transient state
     * @param entity the entity object
     */
    void makeTransient(T entity);
	
    /**
     * transform a entity object to transient state, 
     * perform a lock operation on entity if <code>lock</code> is true
     * @param entity then entity object
	 * @param lock whether to lock entity 
     */
    void makeTransient(T entity, boolean lock);
    
    /**
     * find all entities
     * @return list of entities, nevel <code>null</code>
     */
	List<T> findAll();
	
	/**
	 * find entities by example instance
	 * @param exampleInstance the example instance
     * @return list of entities, nevel <code>null</code>
	 */
	List<T> findByExample(T exampleInstance);
	
	/**
	 * Flush session or entity manager
	 */
	void flush();
	
}
