/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria;

/**
 * @since 2007-11-18
 * @author politics wang
 * @version $Id: OrderDirection.java,v 1.1 2007/11/19 05:25:38 wangzheng Exp $
 */
public enum OrderDirection {
	
	ASC(" asc "),
	DESC(" desc ");
	
	private String direction;
	
	private OrderDirection(String direction) {
		this.direction = direction;
	}

	public String getDirection() {
		return direction;
	}
	
	
}
