/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.springframework.util.CollectionUtils;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi.MultiCriterionsExpression;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi.enhancer.ConditionEnhancer;

/**
 * @since 2007-10-29
 * @author politics wang
 * @version $Id: ConditionContext.java,v 1.17 2007/11/28 08:28:53 wangzheng Exp $
 */
public class ConditionContext implements Serializable {
	
	//~ Static fields/initializers =============================================
	
	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = 8607316482913792348L;
		
	//~ Instance fields ========================================================
	
	private Map<String, Condition> conditions = ConditionInitializerHolder.getInitializer().getEmptyConditionMap();
	
	private Paginater<?> paginater;
	
	private List<Order> orders = new ArrayList<Order>();
	
	private DetachedCriteriaEnhancer detachedCriteriaEnhancer;
	
	//~ Constructors ===========================================================
	
	public ConditionContext() {	
	}
	
	public ConditionContext(Map<String, Condition> conditions, Paginater<?> paginater) {
		super();
		this.conditions = conditions;
		this.paginater = paginater;
	}
	
	public ConditionContext(
		Map<String, Condition> conditions,
		Paginater<?> paginater, 
		List<Order> orders,
		DetachedCriteriaEnhancer detachedCriteriaEnhancer) {
		
		super();
		this.conditions = conditions;
		this.paginater = paginater;
		this.orders = orders;
		this.detachedCriteriaEnhancer = detachedCriteriaEnhancer;
	}
	
	//~ Methods ================================================================
	
	public static ConditionContext prototype() {
		return new ConditionContext();
	}
	
	public void addCondition(String key, Condition condition) {
		getConditions().put(key, condition);
	}
	
	public boolean containsCondition(String key) {
		return getConditions().containsKey(key);
	}
	
	public void addOrder(Order order) {
		getOrders().add(order);
	}
	
	public void setDetachedCriteriaEnhancer(DetachedCriteriaEnhancer detachedCriteriaEnhancer) {
		this.detachedCriteriaEnhancer = detachedCriteriaEnhancer;
	}

	/**
	 * get hibernate {@link DetachedCriteria} from this
	 * @param <T> the type parameter
	 * @param clazz the entity type
	 * @return converted {@link DetachedCriteria}
	 */
	public <T> DetachedCriteria getCriteria(Class<T> clazz) {
		DetachedCriteria criteria = DetachedCriteria.forClass(clazz);
		List<Condition> conditionList = new ArrayList<Condition>(conditions.values());
		Collections.sort(conditionList);		
		Map<String, String> associationPath2alias = new ConcurrentHashMap<String, String>();
		appendConditions(criteria, conditionList, associationPath2alias);		
		appendOrder(criteria);
		criteria = enhanceCriteria(criteria);
		return criteria;
	}

	protected DetachedCriteria enhanceCriteria(DetachedCriteria criteria) {
		if (detachedCriteriaEnhancer != null) {
			criteria = detachedCriteriaEnhancer.enhanceCriteria(criteria);
		}
		return criteria;
	}
	
	private void appendConditions(DetachedCriteria criteria, List<Condition> conditions, Map<String, String> associationPath2alias) {
		List<Criterion> criterions = new ArrayList<Criterion>();
		List<Relation> prepends = new ArrayList<Relation>();
		
		int index = 0;
		
		for (Condition condition : conditions) {
			if (!condition.isPlace()) {
				continue;
			}
			
			if (StringUtils.isNotBlank(condition.getName())) {
				// enhance this condition
				condition = ConditionEnhancer.enhanceCondition(condition);			
				
				Criterion criterion = condition.getSingleCondition(criteria, associationPath2alias, index++);
				criterions.add(criterion);
				prepends.add(condition.getPrepend());
			} else {
				// 处理复合查询
				if (condition.getCompositeConditions().size() > 0) {				
					appendConditions(criteria, condition.getCompositeConditions(), associationPath2alias);
				} else {
					throw new RuntimeException("Wrong condition, " 
						+ "please at least specify basic property or composite conditions"
					);
				}
			} 
		}
		
		if (!CollectionUtils.isEmpty(criterions)) {
			Criterion criterion = new MultiCriterionsExpression(criterions, prepends);
			criteria.add(criterion);
		}
	}
	
	private void appendOrder(DetachedCriteria criteria) {
		appendSelfOrders(criteria);
		appendPaginaterOrder(criteria);
	}

	private void appendSelfOrders(DetachedCriteria criteria) {
		for (Order order : getOrders()) {
			criteria.addOrder(order);
		}
	}
	
	private void appendPaginaterOrder(DetachedCriteria criteria) {
		if (paginater != null && StringUtils.isNotBlank(paginater.getOrderField())) {
			if (paginater.getOrderDirection() == OrderDirection.ASC) {
				criteria.addOrder(Order.asc(paginater.getOrderField()));
			} else {
				criteria.addOrder(Order.desc(paginater.getOrderField()));
			}
		}
	}
	
	public Map<String, Condition> getConditions() {
		if (conditions == null) {
			conditions = ConditionInitializerHolder.getInitializer().getEmptyConditionMap();
		}
		return conditions;
	}

	public void setConditions(Map<String, Condition> conditions) {
		this.conditions = conditions;
	}

	public Paginater<?> getPaginater() {
		return paginater;
	}

	public void setPaginater(Paginater<?> paginater) {
		this.paginater = paginater;
	}

	public List<Order> getOrders() {
		if (orders == null) {
			orders = new ArrayList<Order>();
		}
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}


	
}
