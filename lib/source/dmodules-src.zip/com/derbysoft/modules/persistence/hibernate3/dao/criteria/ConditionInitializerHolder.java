/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.util.ReflectionUtils;

/**
 * @since 2007-11-18
 * @author politics wang
 * @version $Id: ConditionInitializerHolder.java,v 1.2 2007/11/19 08:02:05 wangzheng Exp $
 */
public abstract class ConditionInitializerHolder {
	
	public static final String XWORK_INITIALIZER = "com.derbysoft.modules.web.struts2.condition.XWorkConditionInitializer";
	public static final String DEFAULT_INITIALIZER = XWORK_INITIALIZER;
	
	private static ConditionInitializer initializer;
	private static String initializerClassName;
	
	static {
		initialize();
	}
	
	public static ConditionInitializer getInitializer() {
		Assert.notNull(initializer, "intializer hasn't been initialzed!");
		return initializer;
	}
	
    /**
     * Changes the preferred strategy. Do <em>NOT</em> call this method more than once for a given JVM, as it
     * will reinitialize the strategy and adversely affect any existing threads using the old strategy.
     *
     * @param initializerClassName the fully qualified classname of the strategy that should be used.
     */
    public static void setInitializerClassName(String initializerClassName) {
    	ConditionInitializerHolder.initializerClassName = initializerClassName;
        initialize();
    }
	
	private static void initialize() {
		if (StringUtils.isBlank(initializerClassName)) {
			initializerClassName = DEFAULT_INITIALIZER;
		}
		try {
			initializer = (ConditionInitializer) 
				ClassUtils.getDefaultClassLoader().loadClass(initializerClassName).newInstance();
		} catch (Exception e) {
			ReflectionUtils.handleReflectionException(e);
		}
	}
}
