package com.derbysoft.modules.persistence.hibernate3.dao.criteria;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;

import com.derbysoft.modules.beans.TypeConverter;


/**
 * <p>表示操作数据时要满足的条件之一, 多个这个类型的实例组成一次特定操作的条件. 具体表示列名
 * 称或<code>DTO</code>属性名称依赖于使用它的操作数据的策略而定, 在架构的查询操作中这个条件被
 * 解释为基于<code>DTO</code>的属性</p>
 * <p>这个类的用法如下<ul>
 * <li><code>prepend</code>使用{@link Relation#getDefault() <code>and</code>}</li>
 * <li><code>operator</code>使用{@link Operator#getDefault() <code>like</code>}</li>
 * <li><code>type</code>使用{@link #DEFAULT_TYPE <code>String</code>}</li>
 * <li>属性名和组合条件(<code>compositeCondition</code>至少选择一个</li>
 * <li>如果设置了组合条件,那么忽略条件中的属性名<code>name</code>优先使用组合条件</li></ul>
 * </p>
 * @author scott
 * @author polics wang
 * @since 2006-4-18
 * @version $Id: Condition.java,v 1.15 2007/11/23 07:10:37 wangzheng Exp $
 */
@SuppressWarnings({ "deprecation", "unchecked" })
public class Condition implements Serializable, Comparable<Condition> {
    
	//~ Static fields/initializers =============================================
	
	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = 215198519521859617L;
	
	/** 默认的值类型 */
	public static final Class<String> DEFAULT_TYPE = String.class;
    /** 嵌套属性之间的分隔符 */
    public static final String PROPERTY_SEPARATOR = ".";
    
    //~ Instance fields ========================================================
    
	
	/** 作为检索条件的<code>domain object</code>的属性名称 */
    private String name;
    
    /** 属性要满足的值 */
    private Object value;
    
    /** 经过 {@link TypeConverter} 转换过的值 */
    private Object convertedValue;
    
    /** 属性与值之间的关系 */
    private Operator operator = Operator.getDefault();
    
    /** 属性的类型 */
    private Class<?> type = DEFAULT_TYPE;
    
    /** 如果存在多个属性时这个属性与前一个的关系, 这些属性的第一个不解释这个值 */
    private Relation prepend = Relation.getDefault();
    
    /** 如果存在多个条件, 这个属性决定了组成条件表达式时各个条件的顺序 */
    private int order;
    
    /**
     * 这个条件是否被列入执行查询的条件中, 比如按照目前的统一规范, 不输入值的条件不作为查询
     * 条件, 对于某些情况, 比如查询人员时条件的值是人员<code>id</code>, 但还有姓名作为显示,
     * 在这种情况下保存人员姓名的<code>condition</code>是不作为查询条件的. 如果没有指定这个
     * 值, 缺省值是<code>true</code>, 说明要考虑这个条件. 这个属性与<code>ignoreEmpty</code>
     * 显著区别是这个条件的值不是空, 但在执行查询时仍然要忽略这个条件, 这个属性实际上更多地为表现
     * 层作了支持
     */
    private boolean place = true;
    
    /**
     * 如果这个条件的值是<code>null</code>或对于字符串类型是<code>empty</code>在组装查
     * 询条件时是否忽略这个条件. 对于大多数情况是<code>true</code>, 就是当一个条件没有值
     * 时忽略这个条件. 典型的情形是在<code>UI</code>中的搜索条件, 如果没有填写任何值就不
     * 考虑这个条件
     */
    private boolean ignoreEmpty = true;
    
    /**
     * 当属性名中出现 "." 时是否创建别名, 在两种情况下可能出现 "."
     * <ul>
     * <li>此属性是一个关联属性, 此时 createAlias 应该为 true, 这也是默认情况</li>
     * <li>此属性是一个复合类型, 即 org.hibernate.usertype.CompositeUserType 的实现,  此时 createAlias 应该为 false</li>
     * </ul>
     */ 
    private boolean createAlias = true;
    
    /** 相关的一组条件, 比如组成<code>... and (cond1 or cond2)</code> */
    private List<Condition> compositeConditions = ConditionInitializerHolder.getInitializer().getEmptyConditionList();
    
    //  ~ Constutctors ===========================================================
    
    public Condition() { 	
    }
    
	public Condition(String name, Operator operator, Object value) {
		super();
		this.name = name;
		this.value = value;
		this.operator = operator;
	}
	
	public Condition(String name, Operator operator, Object value,  Class<?> type) {
		this(name, operator, value);
		this.type = type;
	}	
	
    //~ Methods ==================================================================
	
	/**
	 * convert orig value by {@link #getType()}
	 * @see #getValue()
	 * @see #getType()
	 * @param converter the converter
	 */
	public void convert(TypeConverter converter) {
		Object convertedValue = converter.convertValue(getType(), getValue());
		setConvertedValue(convertedValue);
		
		for (Condition foreach : getCompositeConditions()) {
			foreach.convert(converter);
		}
	}
	

	public Criterion getSingleCondition(
		DetachedCriteria criteria, 
		Map<String, String> associationPath2alias, 
		int index) {			
		
		String propertyName = createAliasIfNessary(criteria, associationPath2alias, index);			
		return constructCriterion(propertyName); 	
	}

	private String createAliasIfNessary(DetachedCriteria criteria, Map<String, String> associationPath2alias, int index) {
		// 处理关联查询
		String alias = null;		
		if (name.indexOf(PROPERTY_SEPARATOR) > -1 && isCreateAlias()) {
			StringTokenizer tokenizer = new StringTokenizer(name, PROPERTY_SEPARATOR, false);
			StringBuffer increaceAssociationPath = new StringBuffer();
			
			while (tokenizer.hasMoreTokens()) {
				String token = tokenizer.nextToken();
				if (tokenizer.hasMoreTokens()) {				
					increaceAssociationPath.append(token);
					String associationPath = increaceAssociationPath.toString();
					increaceAssociationPath.append(PROPERTY_SEPARATOR);
					
					String retrivedAlias = associationPath2alias.get(associationPath);
					
					if (retrivedAlias == null) {
						alias = token + "_" + index;
						criteria.createAlias(associationPath, alias);
						associationPath2alias.put(associationPath, alias);
					} else {
						alias = retrivedAlias;
					}
				}
			}			
		}
		
		String propertyName = name;
		if (alias != null) {
			propertyName = alias + name.substring(name.lastIndexOf(PROPERTY_SEPARATOR));
		}
		return propertyName;
	}
	
	

	private Criterion constructCriterion(String propertyName) {
		return CriterionFactory.getCriterion(propertyName, getOperator(), getConvertedValue());
	} 
    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
	 * @return the operator
	 */
	public Operator getOperator() {
		return operator;
	}

	/**
	 * @param operator the operator to set
	 */
	public void setOperator(Operator operator) {
		this.operator = operator;
	}

    /**
	 * @return the prepend
	 */
	public Relation getPrepend() {
		return prepend;
	}

	/**
	 * @param prepend the prepend to set
	 */
	public void setPrepend(Relation prepend) {
		this.prepend = prepend;
	}

	public Class<?> getType() {
        return type;
    }

    public void setType(Class<?> type) {
        this.type = type;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }



    /**
	 * @return the compositeConditions
	 */
	public List<Condition> getCompositeConditions() {
		return compositeConditions;
	}


	/**
	 * @param compositeConditions the compositeConditions to set
	 */
	public void setCompositeConditions(List<Condition> compositeConditions) {
		this.compositeConditions = compositeConditions;
	}


	public boolean isIgnoreEmpty() {
        return ignoreEmpty;
    }

    public void setIgnoreEmpty(boolean ignoreEmpty) {
        this.ignoreEmpty = ignoreEmpty;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }
    
    /**
     * <p>执行查询时是否考虑这个条件, 如果明确设置了<code>false</code>或者这个条件的值是空
     * 并且<code>ignoreEmpty</code>返回<code>true</code>,执行查询时就不考虑这个条件</p>
     * <p>当执行查询时这个方法作为是否考虑这个条件的唯一标准</p>
     * @return 执行查询时是否考虑这个条件
     */
    public boolean isPlace() {
        if (place) {
            /* value 不是空值或 value 是空而且不忽略空值 */
            return (isEmpty() && !ignoreEmpty || !isEmpty() || (getCompositeConditions().size() > 0));
        } else {
            /* 明确指定了不作为查询条件 */
            return false;
        }
    }

    public void setPlace(boolean place) {
        this.place = place;
    }
    
    private boolean isEmpty() {
        if (value == null) {
            return true;
        } else if (value instanceof String) {
            String str = (String) value;
            return StringUtils.isBlank(str);
        } else {
            return false;
        }
    }

	/**
	 * @return the createAlias
	 */
	public boolean isCreateAlias() {
		return createAlias;
	}

	/**
	 * @param createAlias the createAlias to set
	 */
	public void setCreateAlias(boolean createAlias) {
		this.createAlias = createAlias;
	}

	@Override
	public int compareTo(Condition c) {
        int ret = 0;
        if (this.equals(c)) {
            ret = 0;
        } else {
            ret = this.order - c.order;
            /* 这里忽略了 ret == 0 的情况, 因为在 ret == 0 时, 与 equals 方法不一致 */
            ret = (ret > 0) ? 1 : -1;
        }
        return ret;
	}

	/**
	 * @return the convertedValue
	 */
	public Object getConvertedValue() {
		return convertedValue;
	}

	/**
	 * @param convertedValue the convertedValue to set
	 */
	public void setConvertedValue(Object convertedValue) {
		this.convertedValue = convertedValue;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	
}
