/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi.enhancer;

import com.derbysoft.modules.core.BaseRuntimeException;
import com.derbysoft.modules.patterns.cor.Handler;
import com.derbysoft.modules.patterns.cor.SequenceChainedHandlerFactory;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Condition;

/**
 * @since 2007-10-31
 * @author politics wang
 * @version $Id: ConditionEnhancer.java,v 1.7 2007/12/03 01:51:52 xuewei Exp $
 */
public abstract class ConditionEnhancer {
	
	public static Condition enhanceCondition(Condition condition) {				
		SequenceChainedHandlerFactory<Condition> factory = new SequenceChainedHandlerFactory<Condition>();
		factory.addIndividalHandler(new ConditionTypeConverterHandler());		
		factory.addIndividalHandler(new ConditionTrimValueHandler());
		factory.addIndividalHandler(new ConditionLikeValueHandler());
		factory.addIndividalHandler(new ConditionILikeValueHandler());
		factory.addIndividalHandler(new ConditionInValueHandler());
				
		Handler<Condition> chainedHandler = factory.getChainedHandler();
		
		try {
			return chainedHandler.handleRequest(condition);
		} catch (Exception e) {
			throw new BaseRuntimeException("Enhance condition failed : ", e);
		}
	}
	
}
