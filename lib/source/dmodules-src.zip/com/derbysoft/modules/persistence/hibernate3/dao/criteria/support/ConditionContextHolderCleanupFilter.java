/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria.support;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.filter.OncePerRequestFilter;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionContext;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionContextHolder;

/**
 * {@link ConditionContextHolderCleanupFilter} use to clean up thread local stored {@link ConditionContext}, 
 * this is because most of thread pool implementions of webserver are not safe
 * @since 2007-11-4
 * @author politics wang
 * @version $Id: ConditionContextHolderCleanupFilter.java,v 1.1 2007/11/05 08:08:14 wangzheng Exp $
 */
public class ConditionContextHolderCleanupFilter extends OncePerRequestFilter {

	@Override
	protected void doFilterInternal(
		HttpServletRequest request, 
		HttpServletResponse response, 
		FilterChain filterChain)
		throws ServletException, IOException {
		
		ConditionContextHolder.setEmpty();
		filterChain.doFilter(request, response);
	}

}
