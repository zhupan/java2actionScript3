/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi;

import static com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi.HibernateCriteriaReflectionUtils.addOrders;
import static com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi.HibernateCriteriaReflectionUtils.getOrders;
import static com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi.HibernateCriteriaReflectionUtils.getProjection;
import static com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi.HibernateCriteriaReflectionUtils.removeOrders;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.impl.CriteriaImpl.OrderEntry;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.util.Assert;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Paginater;

/**
 * @since 2007-10-30
 * @author politics wang
 * @version $Id: PaginateSupportHibernateTemplate.java,v 1.9 2007/11/29 09:00:08 xuewei Exp $
 */
class PaginateSupportHibernateTemplate extends HibernateTemplate {
	
	private static transient Log logger = LogFactory.getLog(PaginateSupportHibernateTemplate.class);
	
	public PaginateSupportHibernateTemplate(SessionFactory sessionFactory) {
		super(sessionFactory);
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	<T> Paginater<T> paginate(DetachedCriteria criteria, Paginater<?> paginater) {
		PaginateCallBack callBack = new PaginateCallBack(criteria, paginater);
		return (Paginater<T>) execute(callBack, true);
	}
	
	/**
	 * inner class , core implments of enchanced criteria
	 *
	 */
	private class PaginateCallBack<T> implements HibernateCallback {
		
		private DetachedCriteria criteria;
		private Paginater<T> paginater;

		public PaginateCallBack(DetachedCriteria criteria, Paginater<T> paginater) {
			Assert.notNull(criteria, "criteria required");
			Assert.notNull(paginater, "paginater required");
			this.criteria = criteria;
			this.paginater = paginater;
		}

		@SuppressWarnings("unchecked")
		public Object doInHibernate(Session session) throws HibernateException, SQLException {
			Criteria executableCriteria = criteria.getExecutableCriteria(session);				
			prepareCriteria(executableCriteria);
			
			// Get the orginal orderEntries
			OrderEntry[] orderEntries = getOrders(executableCriteria);
			// Remove the orders
			executableCriteria = removeOrders(executableCriteria);				
			// get the original projection
			Projection projection = getProjection(executableCriteria);
			
			int totalCount = getTotalCount(executableCriteria);
            paginater.setTotalCount(totalCount);
            
            executableCriteria = resumeOrderAndProjection(executableCriteria, orderEntries, projection);
            
            setLimit(executableCriteria, paginater.getFirstResult(), paginater.getMaxResults(), totalCount);
		
            List results = executableCriteria.list();
            paginater.setResults(results);
            return paginater;
		}

		private Criteria resumeOrderAndProjection(Criteria executableCriteria, OrderEntry[] orderEntries, Projection projection) {
			executableCriteria.setProjection(projection);
			
			if (projection == null) {
				// Set the ResultTransformer to get the same object structure with hql
				executableCriteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			}              
			// Add the orginal orderEntries
			executableCriteria = addOrders(executableCriteria, orderEntries);
			return executableCriteria;
		}

		private int getTotalCount(Criteria executableCriteria) {
			boolean exception = false;
			Throwable cause = null;
			
			Integer iCount = null;
			try {
				iCount = (Integer) executableCriteria.setProjection(Projections.rowCount()).uniqueResult();	
			} catch (Throwable t) {
				exception = true;
				cause = t;			
			}
			
			if (exception || iCount == null) {
				String message = "Can't execute count operation, may be lost hbm of [ " + criteria.getClass() + " ]";
				if (logger.isErrorEnabled()) {
					logger.error(message, cause);
				}
				throw new RuntimeException(message, cause);
			}				
			
			int totalCount = iCount == null ? 0 : iCount.intValue();
			return totalCount;
		}

		private void setLimit(Criteria executableCriteria, int firstResult, int maxResults, int totalCount) {
			// 修正查询后查询结果不在第一页无法显示的问题, 自动定向到第一页
			if (firstResult >= totalCount) {
				firstResult = Paginater.ZERO;
				paginater.setPageNumber(paginater.getFirstPageNumber());
			}   
			
			if (firstResult >= Paginater.ZERO) {
				executableCriteria.setFirstResult(firstResult);
			}
			if (maxResults > Paginater.ZERO) {
				executableCriteria.setMaxResults(maxResults);
			}
		}
	}
	
}

