/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.usertype;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.usertype.CompositeUserType;
import org.hibernate.util.EqualsHelper;

/**
 * This class provides a skeletal implementation of the {@link CompositeUserType}
 * interface, to minimize the effort required to implement this interface. <p>
 * 
 * @since 2007-10-23
 * @author politics wang
 * @version $Id: AbstractCompositeUserType.java,v 1.2 2007/10/24 05:18:28 wangzheng Exp $
 */
public abstract class AbstractCompositeUserType implements CompositeUserType {

	@Override
	public Object assemble(Serializable cached, SessionImplementor session,
		Object owner) throws HibernateException {
		return cached;
	}

	@Override
	public Object deepCopy(Object value) throws HibernateException {
		return value;
	}

	@Override
	public Serializable disassemble(Object value, SessionImplementor session)
		throws HibernateException {
		return (Serializable) value;
	}

	@Override
	public boolean equals(Object x, Object y) throws HibernateException {
		return EqualsHelper.equals(x, y);
	}

	@Override
	public int hashCode(Object x) throws HibernateException {
		return x.hashCode();
	}

	@Override
	public boolean isMutable() {
		return false;
	}

	@Override
	public Object replace(
		Object original, 
		Object target,
		SessionImplementor session, 
		Object owner) 
		throws HibernateException {
		
		return original;
	}


	@Override
	public void setPropertyValue(Object component, int property, Object value)
		throws HibernateException {
		
		throw new UnsupportedOperationException("Immutable!");
	}

}
