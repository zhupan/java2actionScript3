/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.annotation;

import java.util.Collection;

import org.apache.commons.lang.StringUtils;
import org.hibernate.HibernateException;
import org.hibernate.cfg.AnnotationConfiguration;
import org.springframework.orm.hibernate3.annotation.AnnotationSessionFactoryBean;
import org.springframework.util.Assert;

import com.derbysoft.modules.resource.ClassFinder;
import com.derbysoft.modules.resource.ResourceProbe;
import com.derbysoft.modules.resource.impl.ResourceProbeBasedClassFinder;

/**
 * Subclass of Spring's {@link AnnotationSessionFactoryBean} for Hibernate3,
 * autosearch persistence classes according to a specfied pattern
 * 
 * @see #setPersistenceClassPattern(String)
 * @see ResourceProbe
 * @since 2007-9-20
 * @author politics wang
 * @version $Id: AutoSearchClassAnnotationSessionFactoryBean.java,v 1.6 2008/01/03 11:54:13 wangzheng Exp $
 */
public class AutoSearchClassAnnotationSessionFactoryBean extends
		AnnotationSessionFactoryBean {

	private String persistenceClassPattern;
		
	private ClassFinder classFinder = new ResourceProbeBasedClassFinder();
	
	/**
	 * @param persistenceClassPattern the persistenceClassPattern to set
	 */
	public void setPersistenceClassPattern(String persistenceClassPattern) {
		this.persistenceClassPattern = persistenceClassPattern;
	}
	
	/**
	 * @see AnnotationSessionFactoryBean#postProcessAnnotationConfiguration(org.hibernate.cfg.AnnotationConfiguration)
	 */
	protected void postProcessAnnotationConfiguration(AnnotationConfiguration config) 
		throws HibernateException {
		
		Assert.isTrue(StringUtils.isNotBlank(persistenceClassPattern), "persistenceClassPattern required");
		Collection<Class<?>> persistenceClasses = classFinder.findClass(persistenceClassPattern);
		for (Class<?> clazz : persistenceClasses) {
			config.addAnnotatedClass(clazz);
		}
		postAutoSearchProcessAnnotationConfiguration(config);
	}
		
	/**
	 * To be implemented by subclasses that want to to perform custom
	 * post-processing of the AnnotationConfiguration object after this
	 * FactoryBean performed its default initialization.
	 * @param config the current AnnotationConfiguration object
	 * @throws HibernateException in case of Hibernate initialization errors
	 */
	protected void postAutoSearchProcessAnnotationConfiguration(AnnotationConfiguration config) 
				throws HibernateException {
	}	
}
