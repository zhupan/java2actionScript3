/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria;

import org.springframework.util.Assert;


/**
 * @since 2007-11-4
 * @author politics wang
 * @version $Id: ConditionContextHolder.java,v 1.2 2007/11/05 11:34:31 wangzheng Exp $
 */
public abstract class ConditionContextHolder {
	
	private static final ThreadLocal<ConditionContext> CONDITION_CONTEXTS = new ThreadLocal<ConditionContext>() {
		@Override
		protected ConditionContext initialValue() {
			return ConditionContext.prototype();
		}
	};
	
	public static ConditionContext getConditionContext() {
		return CONDITION_CONTEXTS.get();
	} 
	
	public static void setConditionContext(ConditionContext context) {
		Assert.notNull(context, " condition context required ");
		CONDITION_CONTEXTS.set(context);
	}
	
	public static void setEmpty() {
		CONDITION_CONTEXTS.set(ConditionContext.prototype());
	}
	
}
