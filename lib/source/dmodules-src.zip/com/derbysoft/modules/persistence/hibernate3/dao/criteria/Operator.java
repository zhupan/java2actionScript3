/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria;

/**
 * @since 2007-10-30
 * @author politics wang
 * @version $Id: Operator.java,v 1.12 2008/01/24 08:02:36 wangzheng Exp $
 */
public enum Operator {
	
	LIKE(" like ", "\u90e8\u5206\u5339\u914d"),
	ILIKE(" ilike ", "\u90e8\u5206\u5339\u914d-\u5ffd\u7565\u5927\u5c0f\u5199"),
	EQ(" = ", "\u5b8c\u5168\u5339\u914d"),
	GT(" > ", "\u5927\u4e8e"),
	GE(" >= ", "\u5927\u4e8e\u7b49\u4e8e"),
	LT(" < ", "\u5c0f\u4e8e"),
	LE(" <= ", "\u5c0f\u4e8e\u7b49\u4e8e"),
	NE(" != ", "\u4e0d\u7b49\u4e8e"),
	IS_NULL(" is null ", "\u4e3a\u7a7a"),
	IS_NOT_NULL(" is not null ", "\u4e0d\u4e3a\u7a7a"),
	IN(" in ", "\u5728\u8303\u56f4\u5185"),
	NOT_IN(" not in ", "\u4e0d\u5728\u8303\u56f4\u5185");
	
	private String operator;
	private String alias;
	
	private Operator(String operator, String alias) {
		this.operator = operator;
		this.alias = alias;
	}
	
	/**
	 * @return the operator
	 */
	public String getOperator() {
		return operator;
	}
	
	/**
	 * @return the alias
	 */
	public String getAlias() {
		return alias;
	}

	public static Operator getDefault() {
		return Operator.LIKE;
	}

	@Override
	public String toString() {
		return getOperator();
	}
	
	public static Operator prototype(String operator) {
		for (Operator foreach : Operator.values()) {
			if (foreach.getOperator().equals(operator)) {
				return foreach;
			}
		}
		
		throw new IllegalArgumentException("undefined operator [" + operator + "]");
	}
	
	
}


