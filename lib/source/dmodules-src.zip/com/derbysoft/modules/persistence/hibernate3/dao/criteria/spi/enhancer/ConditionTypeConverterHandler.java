/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi.enhancer;

import com.derbysoft.modules.beans.xwork.XWorkTypeConverter;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Condition;

/**
 * @since 2007-11-4
 * @author politics wang
 * @version $Id: ConditionTypeConverterHandler.java,v 1.1 2007/11/05 08:08:14 wangzheng Exp $
 */
public class ConditionTypeConverterHandler extends
		AbstractConditionValueHandler {

	@Override
	protected Condition doHandleRequest(Condition condition) throws Exception {
		condition.convert(new XWorkTypeConverter());
		return condition;
	}

}
