/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi.enhancer;

import org.hibernate.criterion.InExpression;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Condition;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Operator;
import com.derbysoft.modules.util.ArrayUtils;

/**
 * @see InExpression
 * @since 2007-10-31
 * @author politics wang
 * @version $Id: ConditionInValueHandler.java,v 1.3 2007/11/02 10:41:02 wangzheng Exp $
 */
public class ConditionInValueHandler extends AbstractConditionValueHandler {

	@Override
	protected Condition doHandleRequest(Condition condition) throws Exception {		
		if (condition.getOperator() == Operator.IN || condition.getOperator() == Operator.NOT_IN) {			
			condition.setConvertedValue(ArrayUtils.toArray(condition.getConvertedValue()));
		}
		return condition;
	}
	

}
