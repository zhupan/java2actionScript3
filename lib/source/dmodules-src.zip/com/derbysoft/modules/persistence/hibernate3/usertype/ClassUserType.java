/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.usertype;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.type.Type;
import org.springframework.util.Assert;

/**
 * @since 2008-1-14
 * @author polics wang
 * @author yk
 * @version $Id: ClassUserType.java,v 1.1 2008/01/14 10:05:18 wangzheng Exp $
 */
public class ClassUserType extends AbstractCompositeUserType {

	@Override
	public String[] getPropertyNames() {
		return new String[] {"name"};
	}

	@Override
	public Type[] getPropertyTypes() {
		return new Type[] {Hibernate.STRING};
	}

	@Override
	public Object getPropertyValue(Object component, int property)
		throws HibernateException {
		
		Assert.isInstanceOf(Class.class, component);
		return ((Class<?>) component).getCanonicalName();
	}

	@Override
	public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner)
		throws HibernateException, SQLException {
		
		
		String className = (String) Hibernate.STRING.nullSafeGet(rs, names);
		try {
			return Thread.currentThread().getContextClassLoader().loadClass(className);
		} catch (ClassNotFoundException e) {
			throw new HibernateException(e.getMessage(), e);
		}
	}

	@Override
	public void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session) 
		throws HibernateException, SQLException {
		
		String className = null;
		if (value != null) {
			Assert.isInstanceOf(returnedClass(), value);
			className = ((Class<?>) value).getCanonicalName();
			Hibernate.STRING.nullSafeSet(st, className, index);
		}
	}

	@Override
	public Class<?> returnedClass() {
		return Class.class;
	}

}
