/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao;

import java.util.List;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Condition;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionContext;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Paginater;

/**
 * {@link HibernateQueryProvider} 单独提供查询, 分页功能, 将这两个功能
 * 从 {@link GenericDao} 分离出来使职责更清晰
 * @see ConditionContext
 * @see Condition
 * @see Paginater
 * @since 2007-10-30
 * @author politics wang
 * @version $Id: HibernateQueryProvider.java,v 1.3 2007/11/19 05:25:38 wangzheng Exp $
 */
public interface HibernateQueryProvider {
	
	/**
	 * find results with given {@link ConditionContext}
	 * @param <T> the type parameter
	 * @param conditionContext the conditionContext
	 * @param clazz the entity type
	 * @return the results
	 */
	<T> List<T> findByCondition(ConditionContext conditionContext, Class<T> clazz);
	
	/**
	 * get paginater object with given {@link ConditionContext}
	 * @param <T> the type parameter
	 * @param conditionContext the conditionContext
	 * @param clazz the entity type
	 * @return the paginater object
	 */
	<T> Paginater<T> paginate(ConditionContext conditionContext, Class<T> clazz);

}
