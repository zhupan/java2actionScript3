/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria;

import java.util.List;
import java.util.Map;

/**
 * @since 2007-11-18
 * @author politics wang
 * @version $Id: ConditionInitializer.java,v 1.1 2007/11/19 05:25:38 wangzheng Exp $
 */
public interface ConditionInitializer {
	
	List<Condition> getEmptyConditionList();
	
	Map<String, Condition> getEmptyConditionMap();
	
}
