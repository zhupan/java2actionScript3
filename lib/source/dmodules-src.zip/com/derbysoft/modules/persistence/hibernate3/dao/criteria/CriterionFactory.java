/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria;

import java.lang.reflect.Constructor;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import com.derbysoft.modules.util.ArrayUtils;


/**
 * @since 2007-11-2
 * @author politics wang
 * @version $Id: CriterionFactory.java,v 1.3 2007/11/05 08:08:14 wangzheng Exp $
 */
public abstract class CriterionFactory {
	
	private static transient Log logger = LogFactory.getLog(CriterionFactory.class);
	
	public static Criterion getCriterion(String propertyName, Operator operator, Object value) {
		if (operator == Operator.ILIKE) {
			return Restrictions.ilike(propertyName, value);
		}		
		
		if (operator == Operator.IS_NULL) {
			return Restrictions.isNull(propertyName);
		}
		
		if (operator == Operator.IS_NOT_NULL) {
			return Restrictions.isNotNull(propertyName);
		}
		
		if (operator == Operator.IN || operator == Operator.NOT_IN) {
			Criterion inCriterion = Restrictions.in(propertyName, ArrayUtils.toArray(value));
			if (operator == Operator.IN) {
				return inCriterion;
			}			
			return Restrictions.not(inCriterion);
		} 
		
		return getSimpleExpression(propertyName, operator, value);					
	}

	private static SimpleExpression getSimpleExpression(String propertyName, Operator operator, Object value) {		
		try {
			Constructor<SimpleExpression> constructor = SimpleExpression.class.getDeclaredConstructor(
				new Class[] {
					String.class, 
					Object.class, 
					String.class
				}
			);

			constructor.setAccessible(true);
			
			return (SimpleExpression) constructor.newInstance(
				new Object[] {
					propertyName, 
					value, 
					operator.getOperator()
				}
			);
		} catch (Exception e) {
			String message = "Construct SimpleException Failed ";
			if (logger.isErrorEnabled()) {
				logger.error(message, e);
			}
			throw new RuntimeException(message, e);
		}

	}
	
}
