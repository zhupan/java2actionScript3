/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.orm.ObjectRetrievalFailureException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.util.Assert;

import com.derbysoft.modules.core.BaseRuntimeException;

/**
 * @since 2007-10-23
 * @author politics wang
 * @version $Id: HibernateGenericDaoSupport.java,v 1.14 2008/01/08 09:20:53 wangzheng Exp $
 */
public class HibernateGenericDaoSupport<T, ID extends Serializable> extends HibernateDaoSupport
		implements GenericDao<T, ID> {
	
	private static final int SINGLE = 1;
	
	protected transient Log logger = LogFactory.getLog(getClass());
	
	protected Class<T> entityType;
	
	protected Class<ID> idType;
	
	public HibernateGenericDaoSupport() {
		reflectionGetTypes();
    }

	@SuppressWarnings("unchecked")
	private void reflectionGetTypes() {
		try {
			Type[] typeArguments = ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments();
	        entityType = (Class<T>) typeArguments[0];
	        idType = (Class<ID>) typeArguments[1];
	        logger.info("Construt dao with entityType [" + entityType + "] and idType [" + idType + "]");
		} catch (Exception e) {
			throw new BaseRuntimeException("concreate dao should be parameterized!", e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<T> findAll() {
		return getHibernateTemplate().loadAll(entityType);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> findByExample(T exampleInstance) {
		return getHibernateTemplate().findByExample(exampleInstance);
	}
		
	@SuppressWarnings("unchecked")
	@Override
	public T get(ID id) {
		T result = (T) getHibernateTemplate().get(entityType, id);
		initialize(result);
		return result;
	}

	private void initialize(T result) {
		getHibernateTemplate().initialize(result);
	}

	@SuppressWarnings("unchecked")
	@Override
	public T load(ID id) throws ObjectRetrievalFailureException {
		return load(id, false);
	}

	@SuppressWarnings("unchecked")
	@Override
	public T load(ID id, boolean lock) throws ObjectRetrievalFailureException {
		T result = (T) getHibernateTemplate().load(entityType, id, getLockMode(lock));
		initialize(result);
		return result;
	}

	private LockMode getLockMode(boolean lock) {
		return lock ? LockMode.UPGRADE : null;
	}

	@Override
	public T makePersistent(T entity) {
		getHibernateTemplate().saveOrUpdate(entity);
		return entity;
	}

	@Override
	public void makeTransient(T entity) {
		makeTransient(entity, false);
	}

	@Override
	public void makeTransient(T entity, boolean lock) {
		getHibernateTemplate().delete(entity, getLockMode(lock));
	}
	
	@SuppressWarnings("unchecked")
	protected List<T> findByCriteria(DetachedCriteria criteria) {
		return getHibernateTemplate().findByCriteria(criteria);
	}
	
	@SuppressWarnings({ "hiding", "unchecked" })
	protected T queryForObject(DetachedCriteria criteria) {
		List<T> list = getHibernateTemplate().findByCriteria(criteria);
		Assert.isTrue(list.size() == SINGLE, "Only single records allowed");
		return CollectionUtils.isEmpty(list) ? null : list.iterator().next();
	}

	@Override
	public void flush() {
		getHibernateTemplate().flush();
	}
}
