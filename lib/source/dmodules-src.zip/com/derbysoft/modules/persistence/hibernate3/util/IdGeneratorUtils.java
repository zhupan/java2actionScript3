/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.util;

import org.hibernate.id.UUIDHexGenerator;

/**
 * @since 2007-11-22
 * @author polics wang
 * @version $Id: IdGeneratorUtils.java,v 1.1 2007/11/22 05:54:32 wangzheng Exp $
 */
public abstract class IdGeneratorUtils {
	
	/**
	 * get hex uuid, gurantee unique
	 * @see UUIDHexGenerator
	 * @return hex uuid 
	 */
	public static String getUUIDHex() {
		return new UUIDHexGenerator().generate(null, null).toString();
	}
	
}
