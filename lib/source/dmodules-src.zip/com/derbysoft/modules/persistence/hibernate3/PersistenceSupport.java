/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.hibernate.annotations.GenericGenerator;

import com.derbysoft.modules.util.ToStringStyleFactory;

/**
 * {@link PersistenceSupport} 是所有需要 hibernate 持久化实体的基类
 * @since 2007-9-19
 * @author 王政
 * @version $Id: PersistenceSupport.java,v 1.6 2008/01/28 04:55:17 wangzheng Exp $
 */
@MappedSuperclass
public abstract class PersistenceSupport implements Serializable {
	
	//	~ Instance fields ========================================================
	
	/** uuid */
	@Id
	@GeneratedValue (generator = "system-uuid")
	@GenericGenerator (name = "system-uuid", strategy = "uuid")
	protected String id;
	
    /** 业务实体创建时间 */
	protected Date createdTime;
	
    /** 业务实体最后修改时间 */
	protected Date lastModifiedTime;
    
    /** 当创建一个实体时这个属性用于标志当前执行用户的唯一标识, 这个值的解释属于安全系统 */
	protected String createdUser;
    
    /** 当修改一个实体时这个属性用于标志当前执行用户的唯一标识, 这个值的解释属于安全系统 */
	protected String lastModifiedUser;
        
    /** used by optimistic lock, 通常情况下如果不指定这个值认为不需要并发控制 */
	@Version
	protected Integer version;

    
    //  ~ Methods ================================================================

	@Override
	public String toString() {
		return ReflectionToStringBuilder.reflectionToString(this, ToStringStyleFactory.getArrayMultiLineStyle());
	}
	
	@Override
	public boolean equals(Object obj) {
		boolean superEquals = super.equals(obj);
		if (superEquals) {
			return true;
		}
		
		if (!(getClass().isAssignableFrom(obj.getClass()))) {
			return false;
		}
		
		if (StringUtils.isBlank(getId())) {
			return false;
		}
		
		PersistenceSupport support = (PersistenceSupport) obj;
		if (StringUtils.isBlank(support.getId())) {
			return false;
		}
		
		return getId().equals(support.getId());
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the createdTime
	 */
	public Date getCreatedTime() {
		return createdTime;
	}

	/**
	 * @param createdTime the createdTime to set
	 */
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	/**
	 * @return the lastModifiedTime
	 */
	public Date getLastModifiedTime() {
		return lastModifiedTime;
	}

	/**
	 * @param lastModifiedTime the lastModifiedTime to set
	 */
	public void setLastModifiedTime(Date lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

	/**
	 * @return the createdUser
	 */
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the lastModifiedUser
	 */
	public String getLastModifiedUser() {
		return lastModifiedUser;
	}

	/**
	 * @param lastModifiedUser the lastModifiedUser to set
	 */
	public void setLastModifiedUser(String lastModifiedUser) {
		this.lastModifiedUser = lastModifiedUser;
	}

	/**
	 * @return the version
	 */
	public Integer getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(Integer version) {
		this.version = version;
	}
	
    
    
}
