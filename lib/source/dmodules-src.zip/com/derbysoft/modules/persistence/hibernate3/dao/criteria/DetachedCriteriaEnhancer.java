/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria;

import org.hibernate.criterion.DetachedCriteria;


/**
 * {@link DetachedCriteriaEnhancer} do some post operation after {@link DetachedCriteria} created
 * @see ConditionContext#getCriteria(Class)
 * @since 2007-11-27
 * @author polics wang
 * @version $Id: DetachedCriteriaEnhancer.java,v 1.1 2007/11/28 08:28:53 wangzheng Exp $
 */
public interface DetachedCriteriaEnhancer {
	
	/**
	 * enhance the criteria
	 * @param criteria the orignal criteria
	 * @return enhanced criteria
	 */
	DetachedCriteria enhanceCriteria(DetachedCriteria criteria);
	
}
