/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria;

/**
 * @since 2007-10-30
 * @author politics wang
 * @version $Id: Relation.java,v 1.1 2007/10/30 12:25:53 wangzheng Exp $
 */
public enum Relation {
	
	AND(" and "),
	OR(" or ");
	
	private String relation;
	
	private Relation(String relation) {
		this.relation = relation;
	}

	/**
	 * @return the relation
	 */
	public String getRelation() {
		return relation;
	}
	
	public static final Relation getDefault() {
		return Relation.AND;
	}

	@Override
	public String toString() {
		return getRelation();
	}
	
	
	
}
