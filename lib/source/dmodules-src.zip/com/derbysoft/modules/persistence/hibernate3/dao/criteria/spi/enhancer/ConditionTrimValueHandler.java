/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi.enhancer;

import org.apache.commons.lang.StringUtils;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Condition;

/**
 * @since 2007-10-31
 * @author politics wang
 * @version $Id: ConditionTrimValueHandler.java,v 1.3 2007/11/02 10:41:02 wangzheng Exp $
 */
public class ConditionTrimValueHandler extends AbstractConditionValueHandler {

	@Override
	protected Condition doHandleRequest(Condition condition) throws Exception {
		Object convertedValue = condition.getConvertedValue();
		if (convertedValue == null) {
			convertedValue = StringUtils.EMPTY;
		}
		
		/** 截去两端的空格 */
		if (String.class.isInstance(convertedValue)) {
			convertedValue = ((String) convertedValue).trim();
		}	
		
		condition.setConvertedValue(convertedValue);
		return condition;
	}



}
