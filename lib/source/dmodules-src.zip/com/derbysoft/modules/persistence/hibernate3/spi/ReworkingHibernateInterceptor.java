/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.coheg.com.cn
 *
 * Project framework
 */
package com.derbysoft.modules.persistence.hibernate3.spi;

import java.io.ObjectStreamField;
import java.io.Serializable;
import java.util.Date;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

import com.derbysoft.modules.persistence.hibernate3.PersistenceSupport;

/**
 * @since 2007-9-19
 * @author 王政
 * @version $Id: ReworkingHibernateInterceptor.java,v 1.3 2007/11/28 08:22:56 wangzheng Exp $
 */
public class ReworkingHibernateInterceptor extends EmptyInterceptor {

	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = 7096670444662579481L;
	
	private static final ObjectStreamField[] serialPersistentFields = new ObjectStreamField[0];
        
	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		if (PersistenceSupport.class.isInstance(entity)) {  
			PersistenceSupport support = (PersistenceSupport) entity;
			boolean modified = false;
			for (int i = 0; i < propertyNames.length; i++) {
				if ("createdUser".equals(propertyNames[i])) {
					String remoteUser = getRemoteUser();
					state[i] = remoteUser;
					support.setCreatedUser(remoteUser);
					modified = true;
				} else if ("createdTime".equals(propertyNames[i])) {
					Date createdTime = getCurrentTime();
					state[i] = createdTime;
					support.setCreatedTime(createdTime);
					modified = true;
				} else if ("lastModifiedTime".equals(propertyNames[i])) {
					Date lastModifiedTime = getCurrentTime();
					state[i] = lastModifiedTime;
					support.setLastModifiedTime(lastModifiedTime);
					modified = true;
				}
			}			
			return modified;
		}
		return false;
	}


	@Override
	public boolean onFlushDirty(
		Object entity, 
		Serializable id, 
		Object[] currentState, 
		Object[] previousState, 
		String[] propertyNames, 
		Type[] types) {
		
		if (PersistenceSupport.class.isInstance(entity)) {					
			PersistenceSupport support = (PersistenceSupport) entity;
			boolean modified = false;
			for (int i = 0; i < propertyNames.length; i++) {
				if ("lastModifiedUser".equals(propertyNames[i])) {
					String remoteUser = getRemoteUser();
					currentState[i] = remoteUser;
					support.setLastModifiedUser(remoteUser);
					modified = true;
				} else if ("lastModifiedTime".equals(propertyNames[i])) {
					Date lastModifiedTime = getCurrentTime();
					currentState[i] = lastModifiedTime;
					support.setLastModifiedTime(lastModifiedTime);
					modified = true;
				}
			}			
			return modified;
		}
		return false;
	}
	
	
	/**
	 * get remote login user, subclass can override this method to provide the user,
	 * typically a get from a security context (eg. acegi)
	 * @return remote user
	 */
	protected String getRemoteUser() {
		//TODO need security support
		return null;
	}
	
	/**
	 * get current time, subclass can override this method 
	 * @return current time
	 */
	protected Date getCurrentTime() {
		return new Date();
	}
	
	
	
}
