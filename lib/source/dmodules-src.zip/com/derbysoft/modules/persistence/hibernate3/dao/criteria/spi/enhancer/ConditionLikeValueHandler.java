/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.persistence.hibernate3.dao.criteria.spi.enhancer;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Condition;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Operator;


/**
 * @since 2007-10-31
 * @author politics wang
 * @version $Id: ConditionLikeValueHandler.java,v 1.4 2007/11/29 05:45:39 wangzheng Exp $
 */
public class ConditionLikeValueHandler extends AbstractConditionValueHandler {
	
	public static final String PERCENT = "%";
	
	@Override
	protected Condition doHandleRequest(Condition condition) throws Exception {
		if (condition.getOperator() == Operator.LIKE) {
			condition.setConvertedValue(PERCENT + condition.getConvertedValue() + PERCENT);
		}		
		return condition;
	}
		
	
}
