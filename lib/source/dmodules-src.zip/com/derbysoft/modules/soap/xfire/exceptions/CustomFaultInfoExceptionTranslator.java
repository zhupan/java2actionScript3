/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.soap.xfire.exceptions;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.derbysoft.modules.soap.xfire.fault.CustomFaultInfoException;
import com.derbysoft.modules.support.IgnoreSameTypeThrowableTranslator;

/**
 * @since 2007-11-12
 * @author politics wang
 * @version $Id: CustomFaultInfoExceptionTranslator.java,v 1.5 2007/12/28 09:26:52 wangzheng Exp $
 */
public class CustomFaultInfoExceptionTranslator 
	extends IgnoreSameTypeThrowableTranslator<CustomFaultInfoException> {
	
	private boolean verbose = false;
	
	private boolean fetchRootCause = true;
	
	public CustomFaultInfoExceptionTranslator() {
		super();
	}

	public CustomFaultInfoExceptionTranslator(boolean verbose, boolean fetchRootCause) {
		super();
		this.verbose = verbose;
		this.fetchRootCause = fetchRootCause;
	}
	
	@Override
	protected CustomFaultInfoException doTranslate(Throwable source) {
		Throwable cause = fetchRootCause ? ExceptionUtils.getRootCause(source) : source;
		if (cause == null) {
			cause = source;
		}
		StringBuffer message = new StringBuffer();
		message.append(cause.getMessage());
		
		if (isVerbose()) {
			message.append("<br>Full stack trace [");
			message.append(ExceptionUtils.getFullStackTrace(source));
			message.append("]");
		}
		
		return new CustomFaultInfoException(message.toString(), cause, null);
	}
	
	
	public void setVerbose(boolean verbose) {
		this.verbose = verbose;
	}

	public boolean isVerbose() {
		return verbose;
	}

	public boolean isFetchRootCause() {
		return fetchRootCause;
	}

	public void setFetchRootCause(boolean fetchRootCause) {
		this.fetchRootCause = fetchRootCause;
	}
	
	


}
