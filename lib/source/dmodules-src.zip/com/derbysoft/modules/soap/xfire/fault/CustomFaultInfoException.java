/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.soap.xfire.fault;


import javax.xml.namespace.QName;

import org.codehaus.xfire.fault.FaultInfoException;


/**
 * <class>CustomFaultInfoException</class> 用以传递自定义的异常信息, 遵循 XFire 的要求,
 * 重要信息通过 {@link #getMessage()} 返回, 其他附加信息通过 {@link #getFaultInfo()} 返回,
 * 
 * @see CustomFaultInfo
 * @since 2007-7-10
 * @author politics wang
 * @version $Id: CustomFaultInfoException.java,v 1.1 2007/12/28 08:18:57 wangzheng Exp $
 */
public class CustomFaultInfoException extends FaultInfoException {
	
	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = -3384450400365590975L;
	
	/** fault detail */
	private CustomFaultInfo customFaultInfo;
	
	public CustomFaultInfoException(String message, CustomFaultInfo customFaultInfo) {		
		this(message, null, customFaultInfo);
	}
	
	public CustomFaultInfoException(
		String message, 
		Throwable cause, 
		CustomFaultInfo customFaultInfo) {
		
		super(message, cause);
		this.customFaultInfo = customFaultInfo;
	}

	public CustomFaultInfo getFaultInfo() {
		return customFaultInfo;
	}
	
	public static QName getFaultName() {
		return new QName("http://www.derbysoft.com/fault", "CustomFaultInfo");
	}
}
