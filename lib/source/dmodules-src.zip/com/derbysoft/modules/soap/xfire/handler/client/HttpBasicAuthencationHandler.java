/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.soap.xfire.handler.client;

import org.apache.commons.lang.StringUtils;
import org.codehaus.xfire.MessageContext;
import org.codehaus.xfire.client.Client;
import org.codehaus.xfire.handler.AbstractHandler;
import org.codehaus.xfire.transport.Channel;
import org.springframework.util.Assert;

/**
 * <class>HttpBasicAuthencationHandler</class> used to provide http basic authencation function,
 * please refer to <a href="http://xfire.codehaus.org/HTTP+Transport">xfire user guide</a>
 * @since 2007-8-28
 * @author politics wang
 * @version $Id: HttpBasicAuthencationHandler.java,v 1.1 2007/08/28 06:06:59 wangzheng Exp $
 */
public class HttpBasicAuthencationHandler extends AbstractHandler {
	
	private String username;
	
	private String password;
	
	public HttpBasicAuthencationHandler(String username, String password) {
		Assert.isTrue(StringUtils.isNotBlank(username), "username required");
		Assert.isTrue(StringUtils.isNotBlank(password), "password required");		
		this.username = username;
		this.password = password;
	}

	/**
	 * 
	 * @see org.codehaus.xfire.handler.Handler#invoke(org.codehaus.xfire.MessageContext)
	 */
	public void invoke(MessageContext context) throws Exception {
		Client client = context.getClient();
		client.setProperty(Channel.USERNAME, username);
		client.setProperty(Channel.PASSWORD, password);
	}

}
