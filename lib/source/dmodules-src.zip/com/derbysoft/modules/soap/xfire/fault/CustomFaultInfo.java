/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.soap.xfire.fault;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @since 2007-7-11
 * @author politics wang
 * @version $Id: CustomFaultInfo.java,v 1.1 2007/12/28 08:18:57 wangzheng Exp $
 */
public class CustomFaultInfo implements Serializable {
	
	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = 7759149053876186545L;
	
	/** the fault details */
	private List<String> details = new ArrayList<String>();
	
	public CustomFaultInfo() {
	}
	
	public CustomFaultInfo(List<String> details) {
		this.details = details;
	}

	public List<String> getDetails() {
		return details;
	}

	public void setDetails(List<String> details) {
		this.details = details;
	}

	public void addDetail(String detail) {
		getDetails().add(detail);
	}
	
}
