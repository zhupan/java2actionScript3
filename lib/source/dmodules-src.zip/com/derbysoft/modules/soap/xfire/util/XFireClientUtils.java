/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.soap.xfire.util;

import java.net.MalformedURLException;

import org.codehaus.xfire.client.XFireProxyFactory;
import org.codehaus.xfire.service.Service;
import org.codehaus.xfire.service.binding.BindingProvider;
import org.codehaus.xfire.service.binding.ObjectServiceFactory;
import org.springframework.util.Assert;

/**
 * <code>XFireClientUtils</code> provide some usefull functions to use xfire webservice client
 * @since 2007-8-2
 * @author politics wang
 * @version $Id: XFireClientUtils.java,v 1.5 2008/01/09 13:40:02 wangzheng Exp $
 */
public abstract class XFireClientUtils {
	
	/**
	 * get pojo webserivce client
	 * @param <T> the serivce type
	 * @param serviceUrl the service url
	 * @param serviceClass the service class
	 * @return webservice client instance
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getWebServiceClient(String serviceUrl, Class<T> serviceClass) {		
		return getWebServiceClient(serviceUrl, serviceClass, null);
	}
	
	/**
	 * get pojo webserivce client
	 * @param <T> the serivce type
	 * @param serviceUrl the service url
	 * @param serviceClass the service class
	 * @param bindingProvider the binding provider, <code>null</code> will be ignored
	 * @return webservice client instance
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getWebServiceClient(String serviceUrl, Class<T> serviceClass, BindingProvider bindingProvider) {
		ObjectServiceFactory serviceFactory = new ObjectServiceFactory();
		if (bindingProvider != null) {
			serviceFactory.setBindingProvider(bindingProvider);
		}
		
		Service service = serviceFactory.create(serviceClass);
		XFireProxyFactory proxyFactory = new XFireProxyFactory();
		try {
			Object client = proxyFactory.create(service, serviceUrl);			
			checkType(serviceClass, client);
			return (T) client;
		} catch (MalformedURLException e) {
			throw new RuntimeException("Create XFile Client Failured : ", e);
		}
	}
		
	private static <T> void checkType(Class<T> expectedType, Object value) {
		if (value != null) {
			Assert.isTrue(expectedType.isAssignableFrom(value.getClass()));
		}
	}
}
