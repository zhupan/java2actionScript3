/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.soap.xfire.handler.client;

import org.codehaus.xfire.MessageContext;
import org.codehaus.xfire.client.Client;
import org.codehaus.xfire.handler.AbstractHandler;
import org.codehaus.xfire.transport.http.CommonsHttpMessageSender;

/**
 * <class>HttpClientParamsHandler<class> used to resolve http connection CLOSE_WAIT issue,
 * to use it, simply new instance and add to client out handler
 * @see CommonsHttpMessageSender
 * @since 2007-8-27
 * @author politics wang
 * @version $Id: HttpClientParamsHandler.java,v 1.3 2007/11/12 07:51:20 wangzheng Exp $
 */
public class HttpClientParamsHandler extends AbstractHandler {
	
	/** the default time out values, set to 60 seconds */
	public static final String DEFAULT_TIMEOUT = "60000";
	
	private boolean gzipEnabled = false;
	
	private boolean timeoutEnabled = false;
	
	private String timeout = DEFAULT_TIMEOUT;
	
	/**
	 * @return the timeout
	 */
	public String getTimeout() {
		return timeout;
	}

	public void setTimeout(String timeout) {
		this.timeout = timeout;
	}

	public void setTimeoutEnabled(boolean timeoutEnabled) {
		this.timeoutEnabled = timeoutEnabled;
	}
	
	public void setGzipEnabled(boolean gzipEnabled) {
		this.gzipEnabled = gzipEnabled;
	}

	public void invoke(MessageContext context) throws Exception {
		Client client = context.getClient();
		client.setProperty(CommonsHttpMessageSender.DISABLE_KEEP_ALIVE, Boolean.TRUE.toString());
		client.setProperty(CommonsHttpMessageSender.DISABLE_EXPECT_CONTINUE, Boolean.TRUE.toString());
		if (timeoutEnabled) {
			client.setProperty(CommonsHttpMessageSender.HTTP_TIMEOUT, timeout);
		}		
		if (gzipEnabled) {
			client.setProperty(CommonsHttpMessageSender.GZIP_ENABLED, true);
		}
	}

}
