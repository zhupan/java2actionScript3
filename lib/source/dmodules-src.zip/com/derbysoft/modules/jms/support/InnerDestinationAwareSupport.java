/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.jms.support;


/**
 * This class provides a skeletal implementation of the {@link InnerDestinationAware}
 * interface, to minimize the effort required to implement this interface. <p>
 * 
 * @since 2007-10-29
 * @author politics wang
 * @version $Id: InnerDestinationAwareSupport.java,v 1.1 2007/12/06 05:44:07 wangzheng Exp $
 */
public abstract class InnerDestinationAwareSupport implements InnerDestinationAware {

	protected String innerDestination;

	/**
	 * @see InnerDestinationAware#getInnerDestination()
	 * @return the innerDestination
	 */
	public String getInnerDestination() {
		return innerDestination;
	}

	/**
	 * @see InnerDestinationAware#setInnerDestination(String)
	 * @param innerDestination the innerDestination to set
	 */
	public void setInnerDestination(String innerDestination) {
		this.innerDestination = innerDestination;
	}
	

}
