/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project derby_remote
 */
package com.derbysoft.modules.jms.support;

import java.io.Serializable;

import org.springframework.util.Assert;

/**
 * Generic adapter for {@link InnerDestinationAware} and business object,
 * someone don't hope to implement {@link InnerDestinationAware} can simply
 * construct this adapter with the source object
 * @since 2007-12-13
 * @author polics wang
 * @version $Id: InnerDestinationAwareAdapter.java,v 1.3 2007/12/14 08:15:21 wangzheng Exp $
 */
public class InnerDestinationAwareAdapter extends InnerDestinationAwareSupport {

	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = -4268966351009510515L;
	
	private Serializable source;

	public InnerDestinationAwareAdapter(Serializable source) {
		super();
		Assert.notNull(source, "source required");
		this.source = source;
	}

	public Serializable getSource() {
		return source;
	}
	
}
