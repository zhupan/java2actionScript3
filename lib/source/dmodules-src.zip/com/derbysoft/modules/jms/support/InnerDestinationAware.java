/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.jms.support;

import java.io.Serializable;

/**
 * {@link InnerDestinationAware} used to resolve tcp performance issue,
 * any jms transfer object should implement it
 * 
 * @see InnerDestinationAwareMessageConverter
 * @since 2007-10-26
 * @author politics wang
 * @version $Id: InnerDestinationAware.java,v 1.1 2007/12/06 05:44:07 wangzheng Exp $
 */
public interface InnerDestinationAware extends Serializable {
	
	String getInnerDestination();
	
	void setInnerDestination(String innerDestination);
		
}
