/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.jms.support;

import java.util.ArrayList;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jms.listener.SessionAwareMessageListener;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;
import org.springframework.util.Assert;

/**
 * @since 2007-10-26
 * @author politics wang
 * @version $Id: ReDispatchMessageListener.java,v 1.6 2007/12/29 09:14:56 wangzheng Exp $
 */
public class ReDispatchMessageListener implements MessageListener, InitializingBean {
	
	private static transient Log logger = LogFactory.getLog(ReDispatchMessageListener.class);
	
	private boolean strict = false;
	
	private List<InnerDestinationMessageListenerAdapterMapping> mappings 
		= new ArrayList<InnerDestinationMessageListenerAdapterMapping>();
	
	private InnerDestinationAwareMessageConverter messageConverter = new InnerDestinationAwareMessageConverter();
	
	/**
	 * 
	 * @see javax.jms.MessageListener#onMessage(javax.jms.Message)
	 */
	public void onMessage(Message message) {
		try {		
			InnerDestinationAware innerDestinationAware;
			try {
				innerDestinationAware = messageConverter.extract(message);
			} catch (JMSException e) {
				String info = "Extract message failed, " 
					+ "maybe due to a class not found error " 
					+ "or class not compatible error , just ignore it";
				logger.info(info, e);
				return;
			}
			
			String innerDestination = innerDestinationAware.getInnerDestination();
			InnerDestinationMessageListenerAdapterMapping mapping = lookupMapping(innerDestination);
			
			if (mapping == null) {
				StringBuffer buffer = getDetailMessage(innerDestination);
				buffer.append(", no operation will be execute! ");
				logger.info(buffer);
				return;
			}
			
			MessageListenerAdapter adapter = mapping.getMessageListenerAdapter();
			adapter.setMessageConverter(messageConverter);			
			adapter.onMessage(message);
		} catch (Throwable t) {
			handleListenerException(t);
		}
		
	}
	
    /**
	 * Handle the given exception that arose during listener execution.
	 * The default implementation logs the exception at error level.
	 * <p>This method only applies when used as standard JMS {@link MessageListener}.
	 * In case of the Spring {@link SessionAwareMessageListener} mechanism,
	 * exceptions get handled by the caller instead.
	 * @param ex the exception to handle
	 * @see #onMessage(javax.jms.Message)
	 */
	protected void handleListenerException(Throwable ex) {
		logger.error("Listener execution failed", ex);
	}

	private InnerDestinationMessageListenerAdapterMapping lookupMapping(final String innerDestination) {
		InnerDestinationMessageListenerAdapterMapping mapping = 
			(InnerDestinationMessageListenerAdapterMapping) CollectionUtils.find(
				mappings, 
				new Predicate() {
					public boolean evaluate(Object object) {
						InnerDestinationMessageListenerAdapterMapping foreach = 
							(InnerDestinationMessageListenerAdapterMapping) object;
						Assert.isTrue(StringUtils.isNotEmpty(foreach.getInnerDestination()));
						return foreach.getInnerDestination().equals(innerDestination);
					}		
				}
			);
		
		validateMapping(innerDestination, mapping);		
		return mapping;
	}

	private void validateMapping(String innerDestination, InnerDestinationMessageListenerAdapterMapping mapping) {
		if (strict && mapping == null) {
			StringBuffer errorMessage = getDetailMessage(innerDestination);
			errorMessage.append(", please make sure your producer and consumer used consistent config! ");		
			logger.warn(errorMessage);
			throw new RuntimeException(errorMessage.toString());
		}
	}

	private StringBuffer getDetailMessage(String innerDestination) {
		StringBuffer errorMessage = new StringBuffer();
		errorMessage.append("Inner destination [");
		errorMessage.append(innerDestination);
		errorMessage.append("] not found in [");
		
		for (InnerDestinationMessageListenerAdapterMapping foreach : mappings) {
			errorMessage.append(foreach.getInnerDestination());
			errorMessage.append("  ");
		}
		
		errorMessage.append("]");
		return errorMessage;
	}
	
	
	/**
	 * @param strict the strict to set
	 */
	public void setStrict(boolean strict) {
		this.strict = strict;
	}

	/**
	 * @param destinationDelegateMappings the destinationDelegateMappings to set
	 */
	public void setMappings(List<InnerDestinationMessageListenerAdapterMapping> destinationDelegateMappings) {
		this.mappings = destinationDelegateMappings;
	}

	/**
	 * 
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public void afterPropertiesSet() throws Exception {
		sucessfullRegistered();
	}

	private void sucessfullRegistered() {
		for (InnerDestinationMessageListenerAdapterMapping mapping : mappings) {
			logger.info("Sucessfull registered innerDestination [" + mapping.getInnerDestination() 
						+ "] messageListenerAdapter [" + mapping.getMessageListenerAdapter());
		}
	}

	
}
