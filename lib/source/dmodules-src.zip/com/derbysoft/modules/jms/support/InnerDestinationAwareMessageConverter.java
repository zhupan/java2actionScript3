/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.jms.support;

import java.io.Serializable;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.apache.commons.lang.StringUtils;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.util.Assert;


/**
 * this converter only support {@link InnerDestinationAware}
 * @since 2007-10-26
 * @author politics wang
 * @version $Id: InnerDestinationAwareMessageConverter.java,v 1.2 2007/12/14 08:15:21 wangzheng Exp $
 */
public class InnerDestinationAwareMessageConverter implements MessageConverter {
	
	@SuppressWarnings("unchecked")
	@Override
	public Object fromMessage(Message message) throws JMSException,
		MessageConversionException {
		
		InnerDestinationAware aware = extract(message);
		
		if (InnerDestinationAwareAdapter.class.isInstance(aware)) {
			InnerDestinationAwareAdapter adapter = (InnerDestinationAwareAdapter) aware;
			return adapter.getSource();
		}
		
		return aware;
	}
	
	/**
	 * package level access
	 */
	InnerDestinationAware extract(Message message) throws JMSException {
		Assert.isInstanceOf(ObjectMessage.class, message, "object message support only !");
		Serializable serializable = ((ObjectMessage) message).getObject();
		Assert.isInstanceOf(InnerDestinationAware.class, serializable);
		return (InnerDestinationAware) serializable;
	}
		
	@Override
	public Message toMessage(Object object, Session session)
		throws JMSException, MessageConversionException {
		
		Assert.isInstanceOf(InnerDestinationAware.class, object);
		InnerDestinationAware aware = (InnerDestinationAware) object;
		Assert.isTrue(StringUtils.isNotBlank(aware.getInnerDestination()), "inner destination required");		
		return session.createObjectMessage(aware);		
	}
		
}
