/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.jms.listener;

import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.util.Assert;

import com.derbysoft.modules.jms.client.JmsClientIdWrapper;

/**
 * @since 2007-9-13
 * @author politics wang
 * @version $Id: RedefineClientIdMessageListenerContainer.java,v 1.1 2007/12/06 05:44:07 wangzheng Exp $
 */
public class RedefineClientIdMessageListenerContainer extends
		DefaultMessageListenerContainer {
	
	private JmsClientIdWrapper jmsClientIdWrapper;
	
	/**
	 * @param jmsClientIdWrapper the jmsClientIdWrapper to set
	 */
	public void setJmsClientIdWrapper(JmsClientIdWrapper jmsClientIdWrapper) {
		this.jmsClientIdWrapper = jmsClientIdWrapper;
		super.setClientId(jmsClientIdWrapper.getClientId());
	}

	/**
	 * @see org.springframework.jms.listener.DefaultMessageListenerContainer#initialize()
	 */
	public void initialize() {
		Assert.notNull(jmsClientIdWrapper, "jmsClientIdWrapper required");
		super.initialize();
	}
	
	
	
}
