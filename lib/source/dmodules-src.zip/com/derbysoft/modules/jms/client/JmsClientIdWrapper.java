/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.jms.client;

/**
 * @since 2007-9-13
 * @author politics wang
 * @version $Id: JmsClientIdWrapper.java,v 1.1 2007/12/06 05:44:07 wangzheng Exp $
 */
public class JmsClientIdWrapper {
	
	private String clientId;

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	
	
}
