/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.jms.client;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import com.derbysoft.modules.util.IPUtils;

/**
 * @since 2007-9-13
 * @author politics wang
 * @version $Id: JmsClientIdWrapperFactoryBean.java,v 1.1 2007/12/06 05:44:07 wangzheng Exp $
 */
public class JmsClientIdWrapperFactoryBean implements FactoryBean, InitializingBean {

	private String prefix;
	
	private String suffix;
	
	public Object getObject() throws Exception {
		JmsClientIdWrapper wrapper = new JmsClientIdWrapper();
		StringBuffer buffer = new StringBuffer();
		buffer.append(prefix);
		buffer.append(": ");
		buffer.append(IPUtils.getFirstNoLoopbackAddress());
		buffer.append("@");
		buffer.append(suffix);
		wrapper.setClientId(buffer.toString());
		return wrapper;
	}
		
	public Class<JmsClientIdWrapper> getObjectType() {
		return JmsClientIdWrapper.class;
	}

	public boolean isSingleton() {
		return true;
	}
	
	/**
	 * @param prefix the prefix to set
	 */
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	/**
	 * @param suffix the suffix to set
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	/**
	 * 
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(prefix, "prefix required");
		Assert.notNull(suffix, "suffix required");	
	}

	
	
}
