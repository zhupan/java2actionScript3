/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.databinding.jaxb;

import java.util.ArrayList;
import java.util.Collection;

import javax.xml.bind.JAXBContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

import com.derbysoft.modules.resource.ClassFinder;
import com.derbysoft.modules.resource.impl.ResourceProbeBasedClassFinder;

/**
 * @since 2008-1-3
 * @author polics wang
 * @author yk
 * @version $Id: ClassesPatternBasedJAXBContextFactoryBean.java,v 1.1 2008/02/18 09:41:55 wangzheng Exp $
 */
public class ClassesPatternBasedJAXBContextFactoryBean implements FactoryBean, InitializingBean {
	
	private static Log logger = LogFactory.getLog(ClassesPatternBasedJAXBContextFactoryBean.class);
	
	public static final String DEFAULT_ELIMINATION_CLASS_PATTERN = "**/package-info*";
	
	private String jaxbClassesPattern;
	
	private String eliminationClassesPattern = DEFAULT_ELIMINATION_CLASS_PATTERN;
	
	private ClassFinder classFinder = new ResourceProbeBasedClassFinder();
	
	private Collection<Class<?>> jaxbClasses = new ArrayList<Class<?>>();
	
	@Override
	public Object getObject() throws Exception {
		logger.info("Initializing JAXB Context...");
		JAXBContext context = JAXBContext.newInstance(jaxbClasses.toArray(new Class<?>[jaxbClasses.size()]));
		logger.info("Successful initialize JAXB Context.");
		return context;
	}

	@Override
	public Class<JAXBContext> getObjectType() {
		return JAXBContext.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(jaxbClassesPattern, "jaxbClassesPattern required");
		loadJAXBClasses();
	}

	private void loadJAXBClasses() {
		jaxbClasses = classFinder.findClass(jaxbClassesPattern, eliminationClassesPattern);
	}

	public void setJaxbClassesPattern(String jaxbClassesPattern) {
		this.jaxbClassesPattern = jaxbClassesPattern;
	}
	
	public void setEliminationClassesPattern(String eliminationClassPattern) {
		this.eliminationClassesPattern = eliminationClassPattern;
	}
	
	public static void main(String[] args) throws Exception {
		ClassesPatternBasedJAXBContextFactoryBean bean = new ClassesPatternBasedJAXBContextFactoryBean();
		bean.setJaxbClassesPattern("com/derby/remote/ota/model/*.class");
		bean.afterPropertiesSet();
	}

}
