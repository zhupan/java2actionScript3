/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.databinding.jaxb;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;
import org.w3c.dom.Node;

import com.derbysoft.modules.beans.BeanProcessor;
import com.derbysoft.modules.core.BaseRuntimeExceptionTranslator;

/**
 * @since 2008-1-9
 * @author polics wang
 * @author yk
 * @version $Id: JAXBBeanProcessor.java,v 1.3 2008/01/09 13:46:11 wangzheng Exp $
 */
public class JAXBBeanProcessor implements BeanProcessor {
	
	private JAXBContext jaxbContext;
	
	public JAXBBeanProcessor(JAXBContext jaxbContext) {
		super();
		Assert.notNull(jaxbContext, "jaxbContext required");
		this.jaxbContext = jaxbContext;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T deepClone(T orignal) {
		try {
			Class<T> clazz = (Class<T>) orignal.getClass();
			Node xmlNode = DocumentBuilderHolder.getDocumentBuilder().newDocument();
			JAXBElement<T> toMarshall = new JAXBElement<T>(
				new QName("http://www.opentravel.org/OTA/2003/05", clazz.getSimpleName()), 
				clazz, 
				orignal
			);
			jaxbContext.createMarshaller().marshal(toMarshall, xmlNode);
			JAXBElement<T> unmarshalled = jaxbContext.createUnmarshaller().unmarshal(xmlNode, clazz);
			return unmarshalled.getValue();
		} catch (JAXBException e) {
			throw new BaseRuntimeExceptionTranslator().translate(e);
		}	
	}

	@Override
	public void deepCopy(Object dest, Object orig) {
		try {
			BeanUtils.copyProperties(dest, orig);
			Object clone = deepClone(dest);
			BeanUtils.copyProperties(dest, clone);
		} catch (Exception e) {
			ReflectionUtils.handleReflectionException(e);
		}
	}
	
	private static final class DocumentBuilderHolder {
		
		private static DocumentBuilder documentBuilder;
		
		static {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        factory.setValidating(false);
	        try {
	        	documentBuilder = factory.newDocumentBuilder();
	        } catch (ParserConfigurationException e) {
	        	throw new BaseRuntimeExceptionTranslator().translate(e);
	        }
		}
		
		static DocumentBuilder getDocumentBuilder() {
			return documentBuilder;
		}
	}


}
