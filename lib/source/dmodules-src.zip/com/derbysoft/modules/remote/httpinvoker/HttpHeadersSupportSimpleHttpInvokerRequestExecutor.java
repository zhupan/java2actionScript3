package com.derbysoft.modules.remote.httpinvoker;

import java.io.IOException;
import java.net.HttpURLConnection;

import org.springframework.remoting.httpinvoker.SimpleHttpInvokerRequestExecutor;

import com.derbysoft.modules.remote.http.HttpHeadersProvider;
import com.derbysoft.modules.remote.http.URLConnectionPropertiesSetterUtils;

public class HttpHeadersSupportSimpleHttpInvokerRequestExecutor extends SimpleHttpInvokerRequestExecutor {
	
	private HttpHeadersProvider httpHeadersProvider;
	
	private boolean disableKeepAlive = true;
	
	public HttpHeadersSupportSimpleHttpInvokerRequestExecutor() {
		super();
	}

	public HttpHeadersSupportSimpleHttpInvokerRequestExecutor(HttpHeadersProvider httpHeadersProvider) {
		super();
		this.httpHeadersProvider = httpHeadersProvider;
	}

    /**
     * Provided so subclasses can perform additional configuration if required (eg set additional request
     * headers for non-security related information etc).
     *
     * @param connection the HTTP connection to prepare
     * @param contentLength the length of the content to send
     *
     * @throws IOException if thrown by HttpURLConnection methods
     */
    protected void doPrepareConnection(HttpURLConnection connection, int contentLength)
        throws IOException {
    }
	
	
	@Override
	protected void prepareConnection(HttpURLConnection connection, int contentLength) throws IOException {
		super.prepareConnection(connection, contentLength);
		URLConnectionPropertiesSetterUtils.setProperties(connection, httpHeadersProvider, disableKeepAlive);
		doPrepareConnection(connection, contentLength);
	}

	public void setHttpHeadersProvider(HttpHeadersProvider httpHeadersProvider) {
		this.httpHeadersProvider = httpHeadersProvider;
	}

	public void setDisableKeepAlive(boolean disableKeepAlive) {
		this.disableKeepAlive = disableKeepAlive;
	}
	
	
	
}
