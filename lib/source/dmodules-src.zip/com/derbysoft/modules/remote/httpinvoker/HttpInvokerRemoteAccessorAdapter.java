package com.derbysoft.modules.remote.httpinvoker;

import org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean;
import org.springframework.util.Assert;

import com.derbysoft.modules.remote.RemoteAccessorAdapter;

public class HttpInvokerRemoteAccessorAdapter implements RemoteAccessorAdapter {
	
	private HttpInvokerProxyFactoryBean httpInvokerProxyFactoryBean;

	public HttpInvokerRemoteAccessorAdapter(HttpInvokerProxyFactoryBean httpInvokerProxyFactoryBean) {
		super();
		Assert.notNull(httpInvokerProxyFactoryBean, "httpInvokerProxyFactoryBean required");
		this.httpInvokerProxyFactoryBean = httpInvokerProxyFactoryBean;
		httpInvokerProxyFactoryBean.afterPropertiesSet();
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T getService(Class<T> serviceInterface) {		
		return (T) httpInvokerProxyFactoryBean.getObject();
	}

}
