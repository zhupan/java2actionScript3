package com.derbysoft.modules.remote.httpinvoker;

import org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean;

import com.derbysoft.modules.remote.RemoteAccessorAdapter;
import com.derbysoft.modules.remote.factory.AbstractHttpWebServiceFactory;

public abstract class AbstractHttpInvokerWebServiceFactory extends AbstractHttpWebServiceFactory {
	
	public AbstractHttpInvokerWebServiceFactory(String remoteHost) {
		super(remoteHost);
	}

	protected <T> T getHttpInvokerService(Class<T> clazz, String serviceName) {
		HttpInvokerProxyFactoryBean httpInvokerProxyFactoryBean = creatHttpInvokerFactoryBean(clazz, serviceName);
		HttpHeadersSupportSimpleHttpInvokerRequestExecutor httpInvokerRequestExecutor = createHttpInvokerRequestExecutor();
		httpInvokerProxyFactoryBean.setHttpInvokerRequestExecutor(httpInvokerRequestExecutor);
		RemoteAccessorAdapter adapter = new HttpInvokerRemoteAccessorAdapter(httpInvokerProxyFactoryBean);
		return adapter.getService(clazz);
	}

	private <T> HttpInvokerProxyFactoryBean creatHttpInvokerFactoryBean(Class<T> clazz, String serviceName) {
		HttpInvokerProxyFactoryBean httpInvokerProxyFactoryBean = new HttpInvokerProxyFactoryBean();
		httpInvokerProxyFactoryBean.setServiceUrl(constructServiceUrl(remoteHost, serviceName));
		httpInvokerProxyFactoryBean.setServiceInterface(clazz);
		return httpInvokerProxyFactoryBean;
	}

	private HttpHeadersSupportSimpleHttpInvokerRequestExecutor createHttpInvokerRequestExecutor() {
		HttpHeadersSupportSimpleHttpInvokerRequestExecutor httpInvokerRequestExecutor 
			= new HttpHeadersSupportSimpleHttpInvokerRequestExecutor();
		httpInvokerRequestExecutor.setDisableKeepAlive(disableKeepAlive);
		httpInvokerRequestExecutor.setHttpHeadersProvider(httpHeadersProvider);
		return httpInvokerRequestExecutor;
	}
	
}
