package com.derbysoft.modules.remote;

/**
 * Facade interface that allows to plug in remote access behavio.  
 */
public interface RemoteAccessorAdapter {
	
	<T> T getService(Class<T> serviceInterface);

}
