package com.derbysoft.modules.remote.hessian;

import org.springframework.remoting.caucho.HessianProxyFactoryBean;
import org.springframework.util.Assert;

import com.derbysoft.modules.remote.RemoteAccessorAdapter;

public class Hessian3RemoteAccessorAdapter implements RemoteAccessorAdapter {

	private HessianProxyFactoryBean hessianProxyFactoryBean;
	
	public Hessian3RemoteAccessorAdapter(HessianProxyFactoryBean hessianProxyFactoryBean) {
		Assert.notNull(hessianProxyFactoryBean, "hessianProxyFactoryBean required");
		this.hessianProxyFactoryBean = hessianProxyFactoryBean;
		this.hessianProxyFactoryBean.afterPropertiesSet();
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T getService(Class<T> serviceInterface) {
		return (T) hessianProxyFactoryBean.getObject();
	}

}
