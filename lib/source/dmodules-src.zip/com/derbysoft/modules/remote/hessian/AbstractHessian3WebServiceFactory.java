package com.derbysoft.modules.remote.hessian;

import org.springframework.remoting.caucho.HessianProxyFactoryBean;

import com.derbysoft.modules.remote.RemoteAccessorAdapter;
import com.derbysoft.modules.remote.factory.AbstractHttpWebServiceFactory;

public abstract class AbstractHessian3WebServiceFactory extends AbstractHttpWebServiceFactory {
	
	public AbstractHessian3WebServiceFactory(String remoteHost) {
		super(remoteHost);
	}

	protected <T> T getHessianService(Class<T> clazz, String serviceName) {
		HessianProxyFactoryBean hessianProxyFactoryBean = new HessianProxyFactoryBean();
		hessianProxyFactoryBean.setServiceUrl(constructServiceUrl(remoteHost, serviceName));
		hessianProxyFactoryBean.setServiceInterface(clazz);
		HttpHeadersSupportHessianProxyFactory proxyFactory = new HttpHeadersSupportHessianProxyFactory(httpHeadersProvider);
		proxyFactory.setDisableKeepAlive(disableKeepAlive);
		hessianProxyFactoryBean.setProxyFactory(proxyFactory);
		RemoteAccessorAdapter adapter = new Hessian3RemoteAccessorAdapter(hessianProxyFactoryBean);
		return adapter.getService(clazz);		
	}
	
	
	
}
