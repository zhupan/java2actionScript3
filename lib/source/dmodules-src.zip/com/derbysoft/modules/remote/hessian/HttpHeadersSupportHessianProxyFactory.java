/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.remote.hessian;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

import com.caucho.hessian.client.HessianProxyFactory;
import com.derbysoft.modules.remote.http.HttpHeadersProvider;
import com.derbysoft.modules.remote.http.URLConnectionPropertiesSetterUtils;

/**
 * @since 2008-3-3
 * @author politics wang
 * @version $Id$
 */
public class HttpHeadersSupportHessianProxyFactory extends HessianProxyFactory {
	
	private HttpHeadersProvider httpHeadersProvider;
	
	private boolean disableKeepAlive = true;
	
	public HttpHeadersSupportHessianProxyFactory() {
		super();
	}
	
	public HttpHeadersSupportHessianProxyFactory(HttpHeadersProvider httpHeadersProvider) {
		super();
		this.httpHeadersProvider = httpHeadersProvider;
	}


	@Override
	protected URLConnection openConnection(URL url) throws IOException {
		URLConnection connection = super.openConnection(url);
		URLConnectionPropertiesSetterUtils.setProperties(connection, httpHeadersProvider, disableKeepAlive);	
		return connection;
	}

	public void setDisableKeepAlive(boolean disableKeepAlive) {
		this.disableKeepAlive = disableKeepAlive;
	}
	
	
	
}
