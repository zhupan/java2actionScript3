package com.derbysoft.modules.remote.http;

import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;

public abstract class URLConnectionPropertiesSetterUtils {

	public static void setProperties(
		URLConnection connection, 
		HttpHeadersProvider httpHeadersProvider, 
		boolean disableKeepAlive) {
		
		if (httpHeadersProvider == null) {
			httpHeadersProvider = createEmptyHttpHeadersProvider();
		}
		
		if (disableKeepAlive) {	
			httpHeadersProvider.getHttpHeaders().put("Connection", "close");
		}
		
		URLConnectionPropertiesSetter urlConnectionPropertiesSetter = new DefaultURLConnectionPropertiesSetter(
			connection, 
			httpHeadersProvider
		);
		
		urlConnectionPropertiesSetter.execute();
	}

	private static HttpHeadersProvider createEmptyHttpHeadersProvider() {
		return new HttpHeadersProvider() {
			@Override
			public Map<String, String> getHttpHeaders() {
				return new HashMap<String, String>();
			}
		};
	}
	
}
