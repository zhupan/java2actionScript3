package com.derbysoft.modules.remote.http;

public interface URLConnectionPropertiesSetter {

	void execute();

}
