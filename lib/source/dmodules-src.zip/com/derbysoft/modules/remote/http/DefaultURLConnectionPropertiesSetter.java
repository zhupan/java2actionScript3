package com.derbysoft.modules.remote.http;

import java.net.URLConnection;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;

public class DefaultURLConnectionPropertiesSetter implements URLConnectionPropertiesSetter {
	
	private static Log logger = LogFactory.getLog(DefaultURLConnectionPropertiesSetter.class);
	
	private URLConnection connection;
	
	private HttpHeadersProvider httpHeadersProvider;
	
	public DefaultURLConnectionPropertiesSetter(URLConnection connection, HttpHeadersProvider httpHeadersProvider) {
		Assert.notNull(connection, "connection required");
		this.connection = connection;
		this.httpHeadersProvider = httpHeadersProvider;
	}

	@Override
	public void execute() {
		if (httpHeadersProvider == null) {
			if (logger.isDebugEnabled()) {
				logger.debug("HttpHeaderProvider is null, simple return.");
			}
			return;
		}
		
		Map<String, String> httpHeaders = httpHeadersProvider.getHttpHeaders();
		if (MapUtils.isNotEmpty(httpHeaders)) {
			for (Map.Entry<String, String> entry : httpHeaders.entrySet()) {
				connection.setRequestProperty(entry.getKey(), entry.getValue());
			}
		}	
	}

}
