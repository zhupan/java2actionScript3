/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch1.2
 */
package com.derbysoft.modules.remote.http;

import java.util.Map;

/**
 * @since 2008-3-3
 * @author politics wang
 * @version $Id$
 */
public interface HttpHeadersProvider {
	
	Map<String, String> getHttpHeaders();
	
}
