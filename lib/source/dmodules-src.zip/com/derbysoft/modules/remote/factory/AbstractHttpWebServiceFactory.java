package com.derbysoft.modules.remote.factory;

import com.derbysoft.modules.remote.http.HttpHeadersProvider;

public abstract class AbstractHttpWebServiceFactory extends AbstractWebServiceFactory {

	protected boolean disableKeepAlive = true;
	
	protected HttpHeadersProvider httpHeadersProvider;

	public AbstractHttpWebServiceFactory(String remoteHost) {
		super(remoteHost);
	}

	public void setDisableKeepAlive(boolean disableKeepAlive) {
		this.disableKeepAlive = disableKeepAlive;
	}

	public void setHttpHeadersProvider(HttpHeadersProvider httpHeadersProvider) {
		this.httpHeadersProvider = httpHeadersProvider;
	}

}
