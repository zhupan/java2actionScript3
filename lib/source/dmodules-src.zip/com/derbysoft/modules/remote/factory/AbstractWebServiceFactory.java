package com.derbysoft.modules.remote.factory;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.Assert;

public abstract class AbstractWebServiceFactory {

	public static final String SLASH = "/";
	public static final String DEFAULT_REMOTING_SERVLET_URL_PATTERN = "remoting";
	
	protected String remoteHost;
	
	protected String remotingServletUrlPattern = DEFAULT_REMOTING_SERVLET_URL_PATTERN;

	public AbstractWebServiceFactory(String remoteHost) {
		Assert.notNull(remoteHost, "remoteHost required");
		this.remoteHost = remoteHost;
		if (!this.remoteHost.endsWith(SLASH)) {
			this.remoteHost += SLASH;
		}
	}

	protected String constructServiceUrl(String remoteHost, String serviceName) {
		String slashRemovedServletUrlPattern = removeSlash(remotingServletUrlPattern);
		String slashRemovedServiceName = removeSlash(serviceName);
		return new StringBuilder()
				.append(remoteHost)
				.append(slashRemovedServletUrlPattern)
				.append(SLASH)
				.append(slashRemovedServiceName)
				.toString();
	}
	
	public String removeSlash(String input) {
		return StringUtils.replace(input, SLASH, StringUtils.EMPTY);
	}
	
	public void setRemotingServletUrlPattern(String hessianServletUrlPattern) {
		this.remotingServletUrlPattern = hessianServletUrlPattern;
	}
	
}
