/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dmodules
 */
package com.derbysoft.modules.eip.translator;

/**
 * @since 2008-3-19
 * @author politics wang
 * @version $Id$
 */
public interface Translator<S, D> {
	
	D translate(S source);
	
}
