/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.web.struts2.converter;

import java.util.Map;

import org.apache.struts2.util.StrutsTypeConverter;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Operator;
import com.opensymphony.xwork2.util.TypeConversionException;

/**
 * @since 2007-10-30
 * @author politics wang
 * @version $Id: OperatorTypeConverter.java,v 1.2 2007/11/23 07:10:37 wangzheng Exp $
 */
public class OperatorTypeConverter extends StrutsTypeConverter {

	@SuppressWarnings("unchecked")
	@Override
	public Object convertFromString(Map context, String[] values, Class toClass) {
		if (toClass != Operator.class) {
			throw new TypeConversionException(
				new UnsupportedOperationException(getClass() + " only support " + Operator.class)
			);
		}
		
		if (values == null || values.length == 0) {
			return Operator.getDefault();
		}
		
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < values.length; i++) {
			buffer.append(values[i]);
		}
		String value = buffer.toString();
		
		try {
			return Operator.prototype(value);
		} catch (Exception e) {
			throw new TypeConversionException("Can't convert " + value + " to " + Operator.class);
		}
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public String convertToString(Map context, Object o) {
		if (o == null) {
			return null;
		}
		
		if (!Operator.class.isInstance(o)) {
			throw new TypeConversionException(
				new UnsupportedOperationException(getClass() + " only support " + Operator.class)
			);
		}
		return ((Operator) o).getOperator();
	}



}
