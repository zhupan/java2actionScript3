/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.web.struts2.interceptor;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.ServletActionContext;
import org.displaytag.properties.SortOrderEnum;
import org.displaytag.properties.TableProperties;

import com.derbysoft.modules.web.struts2.PaginateActionSupport;
import com.derbysoft.modules.web.struts2.paginater.DisplayTagPaginaterAdapter;
import com.derbysoft.modules.web.struts2.util.ActionHelper;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

/**
 * @since 2007-10-30
 * @author politics wang
 * @version $Id: InitializePaginaterInterceptor.java,v 1.4 2007/11/19 05:25:38 wangzheng Exp $
 */
public class InitializePaginaterInterceptor extends AbstractInterceptor {

	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = -791725724190817236L;
	
	private static transient Log logger = LogFactory.getLog(InitializePaginaterInterceptor.class);
	
	@SuppressWarnings("unchecked")
	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		Object action = invocation.getAction();
		
		if (PaginateActionSupport.class.isInstance(action)) {
			PaginateActionSupport support = (PaginateActionSupport) action;
			DisplayTagPaginaterAdapter paginater = support.getOrignalPaginater();
			
			TableProperties properties = TableProperties.getInstance(ServletActionContext.getRequest());
            String sPageNumber = ActionHelper.getParam(properties.getPaginationPageNumberParam(), null);
    
            int pageNumber = DisplayTagPaginaterAdapter.DEFAULT_PAGE_NUMBER;
            try {
            	if (StringUtils.isNotBlank(sPageNumber)) {
	            	pageNumber = Integer.parseInt(sPageNumber);	            		
            	}
            } catch (Exception e) {
            	logger.info("Error during parse pageNumber [" + sPageNumber 
            			+ "], use default [" + DisplayTagPaginaterAdapter.DEFAULT_PAGE_NUMBER + "]", e);
            }
            	
            paginater.setPageNumber(pageNumber);
            
            String sort = ActionHelper.getParam(
            	properties.getPaginationSortDirectionParam(), 
            	DisplayTagPaginaterAdapter.DEFAULT_SORT_DIRECTION
            );
            
            if (DisplayTagPaginaterAdapter.DEFAULT_SORT_DIRECTION.equals(sort)) {
            	paginater.setSortDirection(SortOrderEnum.ASCENDING);
            } else {
            	paginater.setSortDirection(SortOrderEnum.DESCENDING);
            }
            
            String orderBy = ActionHelper.getParam(properties.getPaginationSortParam(), null);
            paginater.setSortCriterion(orderBy);
            
            //TODO get from param, but reference hasn't tell me where to get :(
            paginater.setObjectsPerPage(DisplayTagPaginaterAdapter.DEFUALT_PAGE_SIZE);				
		}
		
		return invocation.invoke();
	}


	
}
