/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.web.struts2.support;

import java.io.Serializable;
import java.util.Map;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Condition;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionContext;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Paginater;

/**
 * @since 2007-11-4
 * @author politics wang
 * @version $Id: ConditionContextSessionStore.java,v 1.1 2007/11/05 08:08:14 wangzheng Exp $
 */
public interface ConditionContextSessionStore {
	
	ConditionContext getConditionContext();
	
	<T> void buildConditionContextIfNessary(Map<String, Condition> conditions, Paginater<T> paginater);
	
	void retrivePreviousConditionContext(Serializable sessionKey);
	
	void saveConditionContextAsPrevious(Serializable sessionKey);
	
	void cleanupConditionContext(Serializable sessionKey);
		
}
