/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.web.struts2.support;

import java.io.Serializable;
import java.util.Map;

import org.apache.commons.collections.MapUtils;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Condition;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionContext;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionInitializerHolder;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Paginater;
import com.opensymphony.xwork2.ActionContext;

/**
 * @since 2007-11-4
 * @author politics wang
 * @version $Id: DefaultConditionContextSessionStore.java,v 1.4 2007/11/19 05:25:38 wangzheng Exp $
 */
public class DefaultConditionContextSessionStore implements ConditionContextSessionStore {
	
	private ConditionContext conditionContext;

	@Override
	public <T> void buildConditionContextIfNessary(Map<String, Condition> conditions, Paginater<T> paginater) {
		if (conditionContext == null) {
			conditionContext = ConditionContext.prototype();		
			if (MapUtils.isNotEmpty(conditions)) {
				conditionContext.setConditions(conditions);	
			}			
			conditionContext.setPaginater(paginater);
		}
	}

	@Override
	public ConditionContext getConditionContext() {
		return conditionContext;
	}

	@Override
	public void retrivePreviousConditionContext(Serializable sessionKey) {
		Map<?, ?> sessions = ActionContext.getContext().getSession();
		ConditionContext previousContext = (ConditionContext) sessions.get(sessionKey);
		if (previousContext == null) {
			previousContext = ConditionContext.prototype();
		}
		conditionContext = previousContext;
	}

	@Override
	public void saveConditionContextAsPrevious(Serializable sessionKey) {
		saveConditionContext(sessionKey, conditionContext);
	}

	@SuppressWarnings("unchecked")
	private void saveConditionContext(Serializable sessionKey, ConditionContext conditionContext) {
		Map<Object, Object> sessions = ActionContext.getContext().getSession();
		sessions.put(sessionKey, conditionContext);
	}

	@Override
	public void cleanupConditionContext(Serializable sessionKey) {
		conditionContext.setConditions(ConditionInitializerHolder.getInitializer().getEmptyConditionMap());		
		saveConditionContextAsPrevious(sessionKey);	
	}
	

}
