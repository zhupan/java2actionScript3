/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.web.struts2.paginater;

import java.util.ArrayList;
import java.util.List;

import org.displaytag.pagination.PaginatedList;
import org.displaytag.properties.SortOrderEnum;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.OrderDirection;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Paginater;

/**
 * Adpater class for {@link Paginater} and {@link PaginatedList}
 * @since 2007-10-29
 * @author politics wang
 * @version $Id: DisplayTagPaginaterAdapter.java,v 1.1 2007/11/19 05:25:38 wangzheng Exp $
 */
public class DisplayTagPaginaterAdapter<T> implements Paginater<T>, PaginatedList {
	
	//	~ Static fields ==========================================================
	
	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = -2718274858358023787L;
		
	public static final int DEFAULT_PAGE_NUMBER = 1;
	
	public static final int DEFUALT_PAGE_SIZE = 10;
	
	public static final String DEFAULT_SORT_DIRECTION = "asc";
	
	//	~ Instance fields ========================================================
	
	private int fullListSize;
	
	private List<T> list = new ArrayList<T>();
	
	private int objectsPerPage;
	
	private int pageNumber;
	
	private String searchId;
	
	private String sortCriterion;
	
	private SortOrderEnum sortDirection;	
	
	
	//	~ Methods ================================================================

	/**
	 * @return the fullListSize
	 */
	public int getFullListSize() {
		return fullListSize;
	}
	/**
	 * @param fullListSize the fullListSize to set
	 */
	public void setFullListSize(int fullListSize) {
		this.fullListSize = fullListSize;
	}
	/**
	 * @return the list
	 */
	public List<T> getList() {
		return list;
	}
	/**
	 * @param list the list to set
	 */
	public void setList(List<T> list) {
		this.list = list;
	}
	/**
	 * @return the objectsPerPage
	 */
	public int getObjectsPerPage() {
		return objectsPerPage;
	}
	/**
	 * @param objectsPerPage the objectsPerPage to set
	 */
	public void setObjectsPerPage(int objectsPerPage) {
		this.objectsPerPage = objectsPerPage;
	}
	/**
	 * @return the pageNumber
	 */
	public int getPageNumber() {
		return pageNumber;
	}
	/**
	 * @param pageNumber the pageNumber to set
	 */
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	/**
	 * @return the searchId
	 */
	public String getSearchId() {
		return searchId;
	}
	/**
	 * @param searchId the searchId to set
	 */
	public void setSearchId(String searchId) {
		this.searchId = searchId;
	}
	/**
	 * @return the sortCriterion
	 */
	public String getSortCriterion() {
		return sortCriterion;
	}
	/**
	 * @param sortCriterion the sortCriterion to set
	 */
	public void setSortCriterion(String sortCriterion) {
		this.sortCriterion = sortCriterion;
	}
	/**
	 * @return the sortDirection
	 */
	public SortOrderEnum getSortDirection() {
		return sortDirection;
	}
	/**
	 * @param sortDirection the sortDirection to set
	 */
	public void setSortDirection(SortOrderEnum sortDirection) {
		this.sortDirection = sortDirection;
	}

	@Override
	public int getFirstPageNumber() {
		return DEFAULT_PAGE_NUMBER;
	}

	@Override
	public OrderDirection getOrderDirection() {
		if (getSortDirection() == SortOrderEnum.ASCENDING) {
			return OrderDirection.ASC;
		}
		return OrderDirection.DESC;
	}

	@Override
	public String getOrderField() {
		return getSortCriterion();
	}

	@Override
	public List<T> getResults() {
		return getList();
	}

	@Override
	public int getTotalCount() {
		return getFullListSize();
	}

	@Override
	public void setResults(List<T> results) {
		setList(results);
	}

	@Override
	public void setTotalCount(int totalCount) {
		setFullListSize(totalCount);
	}
	
	@Override
	public int getFirstResult() {
		int pageIndex = getPageNumber() - 1;
		if (pageIndex < ZERO) {
			pageIndex = ZERO;
		}
		return pageIndex * getMaxResults();
	}
	
	@Override
	public int getMaxResults() {
		return getObjectsPerPage();
	}
	

}
