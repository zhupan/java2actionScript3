/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.web.struts2.condition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Condition;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionInitializer;

/**
 * @since 2007-11-18
 * @author politics wang
 * @version $Id: XWorkConditionInitializer.java,v 1.1 2007/11/19 05:25:38 wangzheng Exp $
 */
@SuppressWarnings({ "unchecked", "deprecation" })
public class XWorkConditionInitializer implements ConditionInitializer {

	@Override
	public List<Condition> getEmptyConditionList() {
//		return new XWorkList(Condition.class);
		return new ArrayList<Condition>();
	}
	
	@Override
	public Map<String, Condition> getEmptyConditionMap() {
//		return new XWorkMap(Condition.class);
		return new HashMap<String, Condition>();
	}



}
