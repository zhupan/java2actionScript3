/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.web.struts2;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;

import com.derbysoft.modules.core.BaseRuntimeException;
import com.derbysoft.modules.persistence.hibernate3.dao.HibernateQueryProvider;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Condition;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionContext;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionContextHolder;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionInitializerHolder;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Operator;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Paginater;
import com.derbysoft.modules.web.struts2.interceptor.ConditionInterceptor;
import com.derbysoft.modules.web.struts2.paginater.DisplayTagPaginaterAdapter;
import com.derbysoft.modules.web.struts2.support.ConditionContextSessionStore;
import com.derbysoft.modules.web.struts2.support.DefaultConditionContextSessionStore;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;


/**
 * Top level paginate support action
 * 
 * @see HibernateQueryProvider
 * @see Paginater
 * @see DisplayTagPaginaterAdapter
 * @param <T> default entity type
 * @since 2007-10-30
 * @author politics wang
 * @version $Id: PaginateActionSupport.java,v 1.25 2008/01/24 07:16:03 wangzheng Exp $
 */
public abstract class PaginateActionSupport<T> extends ActionSupport implements Preparable {
	
	//	~ Static fields ==========================================================
	
	public static final String DEFAULT_CONDITION_CONTEXT_KEY_PREFIX = "com.derbysoft.conditionContext : ";
	
	//	~ Instance fields ========================================================
	
	protected Log logger = LogFactory.getLog(getClass());
	
	protected Class<T> defaultEntityType;
	
	protected Map<String, Condition> conditions = ConditionInitializerHolder.getInitializer().getEmptyConditionMap();
	
	protected DisplayTagPaginaterAdapter<T> paginaterAdapter = new DisplayTagPaginaterAdapter<T>();
	
	protected ConditionContextSessionStore conditionContextSessionStore = new DefaultConditionContextSessionStore();
	
	protected HibernateQueryProvider hibernateQueryProvider;
	
	protected String conditionContextKeyPrefix = DEFAULT_CONDITION_CONTEXT_KEY_PREFIX;
	
	//  ~ Constutctors ===========================================================
	
	public PaginateActionSupport() {
		reflectionGetTypes();
	}
	

	//  ~ Methods ================================================================
	
	@SuppressWarnings("unchecked")
	public final DisplayTagPaginaterAdapter<?> getPaginater() {
		// 这是一个补丁, 由于整个 ConditionContext 被放进了 session, paginater 可能取到一个无效对象,
		// 将 paginater 再 set 回去以避免这个问题, 事实上, paginater 现在不需要记忆功能
		getConditionContext().setPaginater(paginaterAdapter);
		
		rebuildConditionContext(getConditionContext());

		try {
			Class<?> entityType = getEntityType();
			Paginater<?> paginater = hibernateQueryProvider.paginate(getConditionContext(), entityType);
			Assert.isInstanceOf(
				DisplayTagPaginaterAdapter.class, 
				paginater, 
				DisplayTagPaginaterAdapter.class + " support only "
			);
			paginaterAdapter = (DisplayTagPaginaterAdapter) paginater;
		} catch (Exception e) {
			// ognl will ingore any exception, so what we can do is log the exception
			logger.error("Paginate failed : " + e.getLocalizedMessage() , e);
		}
		
		return paginaterAdapter;
	}
	
	/**
	 * 清除已记录的查询条件和分页参数
	 * @see ConditionInterceptor#setRememberConditionContext(boolean)
	 */
	public final String cleanupConditionContext() {
		conditionContextSessionStore.cleanupConditionContext(getSessionKey());
		conditions = getConditionContext().getConditions();
		ConditionContextHolder.setEmpty();
		addActionMessage("Condition cleanuped");
		return SUCCESS;
	}
		
	public final void buildConditionContextIfNessary() {	
		conditionContextSessionStore.buildConditionContextIfNessary(conditions, paginaterAdapter);	
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	public final void retrivePreviousConditionContext() {
		conditionContextSessionStore.retrivePreviousConditionContext(getSessionKey());
		conditions = getConditionContext().getConditions();
	}
	
	public final void saveConditionContextAsPrevious() {
		conditionContextSessionStore.saveConditionContextAsPrevious(getSessionKey());
	}

	private Class<?> getEntityType() {
		Class<?> entityType = getCustomEntityType();
		if (entityType == null) {
			entityType = defaultEntityType;
		}
		return entityType;
	}
	
	private Serializable getSessionKey() {
		String sessionKey = conditionContextKeyPrefix + getSessionKeyClass().getName();
		String suffix = getSessionKeySuffix();
		if (suffix != null) {
			sessionKey += suffix;
		}		
		return sessionKey;
	}
	
	public final Operator getDefaultOperator() {
		return Operator.getDefault();
	}
	
	@Override
	public final void prepare() throws Exception {
		Assert.notNull(hibernateQueryProvider, "hibernateQueryProvider required");
		doPrepare();
	}
	
	/**
	 * 子类可覆盖此方法做一些初始化工作
	 * @throws Exception if exception happens
	 */
	protected void doPrepare() throws Exception {
	}
	
	/**
	 * 得到自定义的 entity type, 如果此方法返回非 <code>null</code> 的值, 那么
	 * {@link #getPaginater()} 将使用这个值而不再使用默认的 {@link #defaultEntityType},
	 * 子类可覆盖此方法实现 parent-child 在同一页面上的业务
	 * @see #getPaginater()
	 * @see #getEntityType()
	 * @param <C> the custom entity type param
	 * @return custom entity type
	 */
	protected <C> Class<C> getCustomEntityType() {
		return null;
	}
	
	/**
	 * allow concreate class overide this method to rebuild the {@link ConditionContext}
	 * @param context the context
	 */
	protected void rebuildConditionContext(ConditionContext context) {		
	}
	
	/**
	 * 得到存储 condition 的 session key  class, 默认实现是得到当前 class, 
	 * 意味着只有同一个 class 的 condition 可以被共享, 如果同一业务
	 * 模块的实现是一个类层次而不是一个类, 那么可以考虑覆盖此方法以实现 
	 * condition 的共享
	 * @see #getSessionKey()
	 * @see #getSessionKeySuffix()
	 * @return the class
	 */
	protected Class<?> getSessionKeyClass() {
		return getClass();
	}
	
	/**
	 * 得到存储 condition 的 session key suffix, 默认返回 <code>null</code>, 此时
	 * {@link #getSessionKey()} 将会忽略这个值, 如果不同业务模块复用了同一 action,
	 * 那么可以考虑覆盖此方法以避免 condition 的共享
	 * @see #getSessionKey()
	 * @see #getSessionKeyClass()
	 * @return the session key suffix
	 */
	protected String getSessionKeySuffix() {
		return null;
	}
	
	@SuppressWarnings("unchecked")
	private void reflectionGetTypes() {
		try {
			Type[] typeArguments = ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments();
	        defaultEntityType = (Class<T>) typeArguments[0];
	        logger.debug("Construt [" + getClass() + "] with entityType [" + defaultEntityType + "]");
		} catch (Exception e) {
			throw new BaseRuntimeException("concreate action [" + getClass() +  "] should be parameterized!", e);
		}
	}
	
	public final void setConditionContextKeyPrefix(String conditionSessionKeyPrefix) {
		this.conditionContextKeyPrefix = conditionSessionKeyPrefix;
	}

	public final void setHibernateQueryProvider(HibernateQueryProvider hibernateQueryProvider) {
		this.hibernateQueryProvider = hibernateQueryProvider;
	}

	public final Map<String, Condition> getConditions() {
		return conditions;
	}

	public final DisplayTagPaginaterAdapter<T> getOrignalPaginater() {
		return paginaterAdapter;
	}
	
	public final ConditionContext getConditionContext() {
		return conditionContextSessionStore.getConditionContext();
	}
	
}
