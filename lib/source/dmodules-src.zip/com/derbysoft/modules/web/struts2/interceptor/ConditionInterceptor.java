/*
 * Copyright 2005-2010 the original author or authors.
 * 
 *      http://www.derbysoft.com/
 *
 * Project dswitch-2.0
 */
package com.derbysoft.modules.web.struts2.interceptor;

import java.util.Map;

import com.derbysoft.modules.persistence.hibernate3.dao.criteria.Condition;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionContext;
import com.derbysoft.modules.persistence.hibernate3.dao.criteria.ConditionContextHolder;
import com.derbysoft.modules.web.struts2.PaginateActionSupport;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

/**
 * @since 2007-10-30
 * @author politics wang
 * @version $Id: ConditionInterceptor.java,v 1.6 2007/11/12 10:16:37 wangzheng Exp $
 */
public class ConditionInterceptor extends AbstractInterceptor {

	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = 7009758385144307870L;
	
	protected boolean rememberConditionContext = true;
	
	
	/**
	 * @param rememberCondition the rememberCondition to set
	 */
	public void setRememberConditionContext(boolean rememberCondition) {
		this.rememberConditionContext = rememberCondition;
	}
	

	@SuppressWarnings("unchecked")
	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		Object action = invocation.getAction();
		
		if (PaginateActionSupport.class.isInstance(action)) {
			PaginateActionSupport support = (PaginateActionSupport) action;	
			support.buildConditionContextIfNessary();
			ConditionContext conditionContext = support.getConditionContext();
			
			if (rememberConditionContext && conditionContext.getConditions().isEmpty()) {
				support.retrivePreviousConditionContext();			
			}
			
			if (rememberConditionContext) {
				support.saveConditionContextAsPrevious();
			}
			
			convert2stringIfNecessary(support.getConditions());
			ConditionContextHolder.setConditionContext(support.getConditionContext());
		}
		
		return invocation.invoke();
	}
	
	private void convert2stringIfNecessary(Map<String, Condition> conditions) {
		for (Condition condition : conditions.values()) {
			Object origValue = condition.getValue();			
			if (String[].class.isInstance(origValue)) {
				String[] array = (String[]) origValue;
				if (array.length == 1) {
					condition.setValue(array[0]);
				}
			}
		}
	}

}
