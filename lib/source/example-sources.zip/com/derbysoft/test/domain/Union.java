package com.derbysoft.test.domain;

public class Union extends User {

}
