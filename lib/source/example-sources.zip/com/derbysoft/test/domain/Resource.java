package com.derbysoft.test.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

public class Resource implements Serializable {

	private Long id;

	private Date createDate;

	private Date updateDate;

	private String title;

	private String content;

	private String type;

	private User user;

	private Integer sumLoadCount;

	private Set attachmentFiles;

	private Set resourceDownLog;

	public Set getResourceDownLog() {
		return resourceDownLog;
	}

	public void setResourceDownLog(Set resourceDownLog) {
		this.resourceDownLog = resourceDownLog;
	}

	public Set getAttachmentFiles() {
		return attachmentFiles;
	}

	public void setAttachmentFiles(Set attachmentFiles) {
		this.attachmentFiles = attachmentFiles;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getSumLoadCount() {
		return sumLoadCount;
	}

	public void setSumLoadCount(Integer sumLoadCount) {
		this.sumLoadCount = sumLoadCount;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
}
