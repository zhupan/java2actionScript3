package com.derbysoft.test.domain;

import java.util.Date;
import java.util.Set;

public class NjPhoto {

	private Long id;

	private String name;

	private Set<AttachmentFile> attachments;

	private Date createDate;

	public Set<AttachmentFile> getAttachments() {
		return attachments;
	}

	public void setAttachments(Set<AttachmentFile> attachments) {
		this.attachments = attachments;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
