package com.derbysoft.test.domain.enums;

public enum Sex {

	BOY("boy"), GIRL("girl");
	private String description;

	private Sex(String description) {
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	public String getName() {
		return this.name();
	}

	@Override
	public String toString() {
		return this.ordinal() + ":" + this.description;
	}

}
