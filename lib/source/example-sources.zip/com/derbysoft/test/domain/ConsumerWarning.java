package com.derbysoft.test.domain;

import java.util.Date;

public class ConsumerWarning {

	private Long id;

	private String title;

	private String content;

	private User releaser;
	
	private Date createDate;

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getReleaser() {
		return releaser;
	}

	public void setReleaser(User releaser) {
		this.releaser = releaser;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

}
