package com.derbysoft.test.domain;

import java.io.Serializable;
import java.util.Date;

public class GuideLinkGroup implements Serializable {

    private Long id;

    private String groupNum;

    private Date beginDate;

    private Date endDate;

    private String groupArea;

    private String travelLine;

    private Guide guide;

    private Agency agency;

    private Date createDate;

    private Date updateDate;

    private Long daysNum;

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getGroupArea() {
        return groupArea;
    }

    public void setGroupArea(String groupArea) {
        this.groupArea = groupArea;
    }

    public String getGroupNum() {
        return groupNum;
    }

    public void setGroupNum(String groupNum) {
        this.groupNum = groupNum;
    }

    public Guide getGuide() {
        return guide;
    }

    public void setGuide(Guide guide) {
        this.guide = guide;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Agency getTravelBureau() {
        return agency;
    }

    public void setTravelBureau(Agency agency) {
        this.agency = agency;
    }

    public String getTravelLine() {
        return travelLine;
    }

    public void setTravelLine(String travelLine) {
        this.travelLine = travelLine;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

	public Long getDaysNum() {
		return daysNum;
	}

	public void setDaysNum(Long daysNum) {
		this.daysNum = daysNum;
	}

}
