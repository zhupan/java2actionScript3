package com.derbysoft.test.domain;

public class Message extends Resource {

	private String receiverType;

	private Boolean shownOnBWS;

	public Boolean getShownOnBWS() {
		return shownOnBWS;
	}

	public void setShownOnBWS(Boolean shownOnBWS) {
		this.shownOnBWS = shownOnBWS;
	}

	public String getReceiverType() {
		return receiverType;
	}

	public void setReceiverType(String receiverType) {
		this.receiverType = receiverType;
	}

}
