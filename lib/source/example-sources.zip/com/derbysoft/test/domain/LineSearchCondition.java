package com.derbysoft.test.domain;

public class LineSearchCondition {

	private Long leastDaysNum;

	private Long mostDaysNum;

	private Long leastPrice;

	private Long mostPrice;

	public Long getLeastDaysNum() {
		return leastDaysNum;
	}

	public void setLeastDaysNum(Long leastDaysNum) {
		this.leastDaysNum = leastDaysNum;
	}

	public Long getLeastPrice() {
		return leastPrice;
	}

	public void setLeastPrice(Long leastPrice) {
		this.leastPrice = leastPrice;
	}

	public Long getMostDaysNum() {
		return mostDaysNum;
	}

	public void setMostDaysNum(Long mostDaysNum) {
		this.mostDaysNum = mostDaysNum;
	}

	public Long getMostPrice() {
		return mostPrice;
	}

	public void setMostPrice(Long mostPrice) {
		this.mostPrice = mostPrice;
	}

}
