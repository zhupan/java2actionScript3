package com.derbysoft.test.domain;

import java.util.Date;

public class JoinEnterprise {

	private Long id;

	private String enterpriseName;

	private String enterpriseWebsite;

	private Date createDate;

	public String getEnterpriseName() {
		return enterpriseName;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}

	public String getEnterpriseWebsite() {
		return enterpriseWebsite;
	}

	public void setEnterpriseWebsite(String enterpriseWebsite) {
		this.enterpriseWebsite = enterpriseWebsite;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
