package com.derbysoft.test.domain;

public class AttachmentFile {

    private String url;

	private String attachmentDiscernId;

	private String name;

	private Long size;

	private Resource resource;

	private NjPhoto njPhoto;

	public NjPhoto getNjPhoto() {
		return njPhoto;
	}

	public void setNjPhoto(NjPhoto njPhoto) {
		this.njPhoto = njPhoto;
	}

	public Resource getResource() {
		return resource;
	}

	public void setResource(Resource resource) {
		this.resource = resource;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getAttachmentDiscernId() {
		return attachmentDiscernId;
	}

	public void setAttachmentDiscernId(String attachmentDiscernId) {
		this.attachmentDiscernId = attachmentDiscernId;
	}

}
