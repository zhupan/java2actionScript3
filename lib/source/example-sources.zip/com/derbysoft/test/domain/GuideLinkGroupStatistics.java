package com.derbysoft.test.domain;

public class GuideLinkGroupStatistics {

	private GuideLinkGroup guideLinkGroup;

	private Long totalDays;

	private Long totoalLinkGroupsCount;

	public GuideLinkGroup getGuideLinkGroup() {
		return guideLinkGroup;
	}

	public void setGuideLinkGroup(GuideLinkGroup guideLinkGroup) {
		this.guideLinkGroup = guideLinkGroup;
	}

	public Long getTotalDays() {
		return totalDays;
	}

	public void setTotalDays(Long totalDays) {
		this.totalDays = totalDays;
	}

	public Long getTotoalLinkGroupsCount() {
		return totoalLinkGroupsCount;
	}

	public void setTotoalLinkGroupsCount(Long totoalLinkGroupsCount) {
		this.totoalLinkGroupsCount = totoalLinkGroupsCount;
	}

}
