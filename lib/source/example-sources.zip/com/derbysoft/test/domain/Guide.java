package com.derbysoft.test.domain;

import java.util.Date;

public class Guide extends User {

    private String cardNo;

    private String sex;

    private String nation;

    private String education;

    private String language;

    private String grade;

    private Agency agency;

    private String longevityNo;

    private String gradeNo;

    private String idCardNo;

    private Date sendCardDate;

    private Date yearcheckDate;

    private Integer cent;

    private Date createDate;

    private String telNo;

    private String icMobileNo;

    private String mobileNo;

    private String address;


    public Guide() {

    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public Integer getCent() {
        return cent;
    }

    public void setCent(Integer cent) {
        this.cent = cent;
    }


    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getGradeNo() {
        return gradeNo;
    }

    public void setGradeNo(String gradeNo) {
        this.gradeNo = gradeNo;
    }

    public String getIcMobileNo() {
        return icMobileNo;
    }

    public void setIcMobileNo(String icMobileNo) {
        this.icMobileNo = icMobileNo;
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo;
    }


    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getLongevityNo() {
        return longevityNo;
    }

    public void setLongevityNo(String longevityNo) {
        this.longevityNo = longevityNo;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public Date getSendCardDate() {
        return sendCardDate;
    }

    public void setSendCardDate(Date sendCardDate) {
        this.sendCardDate = sendCardDate;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Agency getTravelBureau() {
        return agency;
    }

    public void setTravelBureau(Agency agency) {
        this.agency = agency;
    }

    public Date getYearcheckDate() {
        return yearcheckDate;
    }

    public void setYearcheckDate(Date yearcheckDate) {
        this.yearcheckDate = yearcheckDate;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

}
